import React, { useState } from 'react';
import {
  Search,
  ShieldAlert,
  Building2,
  ShieldCheck,
  Mountain,
  Download,
  FolderArchive,
  Globe
} from 'lucide-react';
import { UserRole } from '../types/index.ts';
import { HostingModal } from './HostingModal.tsx';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  cloudPoints: number;
  onOpenSos: () => void;
  onOpenPointsModal: () => void;
  savedCount: number;
  onOpenSavedModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  userRole,
  setUserRole,
  cloudPoints,
  onOpenSos,
  onOpenPointsModal
}) => {
  const isNavyHeader = currentTab === 'explore';
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [hostingModalTab, setHostingModalTab] = useState<'live' | 'deploy' | 'download'>('live');
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);

  const handleBlobDownload = async (url: string, filename: string, mimeType: string) => {
    try {
      setDownloadingFile(filename);
      const response = await fetch(url);
      const arrayBuffer = await response.arrayBuffer();
      const blob = new Blob([arrayBuffer], { type: mimeType });
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    } catch {
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setDownloadingFile(null);
    }
  };

  const navItems = [
    { id: 'explore', label: 'Khám phá' },
    { id: 'stay', label: 'Lưu trú' },
    { id: 'map', label: 'Bản đồ' },
    { id: 'bus', label: 'Xe khách' },
    { id: 'weather', label: 'Săn mây' },
    { id: 'community', label: 'Cẩm nang & Cộng đồng' },
    { id: 'verified', label: 'Về chúng tôi' }
  ];

  return (
    <>
      <header
        className={`sticky top-0 z-40 transition-colors duration-200 ${
          isNavyHeader
            ? 'bg-[#04244d]/95 backdrop-blur-md border-b border-white/10 text-white'
            : 'bg-white/95 backdrop-blur-md border-b border-slate-200/90 text-slate-900 shadow-xs'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Main 3-Zone Header matching https://taxuaslay1.vercel.app/ */}
          <div className="flex items-center justify-between gap-8 h-20">
            {/* Zone 1: Brand Lockup */}
            <button
              type="button"
              onClick={() => setCurrentTab('explore')}
              className="flex items-center gap-3 text-left cursor-pointer group shrink-0"
            >
              <div
                className={`relative w-10 h-10 rounded-full flex items-center justify-center transition-transform group-hover:scale-105 ${
                  isNavyHeader
                    ? 'bg-white text-[#073161]'
                    : 'bg-[#073161] text-white'
                }`}
              >
                <Mountain className="w-5 h-5 stroke-[2.2]" />
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-[#04244d]" />
              </div>
              <div>
                <div
                  className={`font-extrabold text-sm tracking-[0.12em] uppercase leading-tight whitespace-nowrap ${
                    isNavyHeader ? 'text-white' : 'text-[#073161]'
                  }`}
                >
                  TÀ XÙA TRIP
                </div>
                <div
                  className={`text-[11px] font-normal tracking-wide whitespace-nowrap ${
                    isNavyHeader ? 'text-slate-300' : 'text-slate-500'
                  }`}
                >
                  Đi thật. Biết trước.
                </div>
              </div>
            </button>

            {/* Zone 2: Clean Single-Line Navigation Links */}
            <nav className="hidden lg:flex items-center gap-7">
              {navItems.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setCurrentTab(item.id)}
                    className={`text-sm font-semibold whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 cursor-pointer ${
                      isActive
                        ? isNavyHeader
                          ? 'text-white border-amber-400'
                          : 'text-[#073161] border-[#073161]'
                        : isNavyHeader
                        ? 'text-white/85 hover:text-white border-transparent'
                        : 'text-slate-700 hover:text-[#073161] border-transparent'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>

            {/* Zone 3: Single Primary Action "Tìm chuyến đi" */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setCurrentTab('stay')}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isNavyHeader
                    ? 'bg-[#031d3d]/90 hover:bg-[#031d3d] text-white border border-white/25 shadow-sm'
                    : 'bg-[#073161] hover:bg-[#0a3f7c] text-white shadow-sm'
                }`}
              >
                <Search className="w-4 h-4" />
                <span>Tìm chuyến đi</span>
              </button>
            </div>
          </div>

          {/* Subtle Utility & Role Bar below main header */}
          <div
            className={`flex items-center justify-between gap-2 py-1.5 border-t text-[11px] overflow-x-auto no-scrollbar ${
              isNavyHeader
                ? 'border-white/10 text-slate-300'
                : 'border-slate-100 text-slate-500'
            }`}
          >
            <div className="flex items-center gap-3 whitespace-nowrap">
              <span>THẬT · HIỂU · TRỌN VẸN</span>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={onOpenPointsModal}
                className={`font-semibold hover:underline cursor-pointer ${
                  isNavyHeader ? 'text-teal-300' : 'text-teal-700'
                }`}
              >
                ☁️ {cloudPoints} Điểm Mây tích lũy
              </button>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={onOpenSos}
                className={`inline-flex items-center gap-1 font-bold hover:underline cursor-pointer ${
                  isNavyHeader ? 'text-rose-300' : 'text-rose-600'
                }`}
                aria-label="Cứu hộ khẩn cấp SOS Tà Xùa"
              >
                <ShieldAlert className="w-3 h-3" />
                <span>Cứu hộ Đèo Chẹn 24/7</span>
              </button>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => {
                  setHostingModalTab('live');
                  setIsDownloadModalOpen(true);
                }}
                className={`inline-flex items-center gap-1.5 font-extrabold px-2.5 py-0.5 rounded-full cursor-pointer transition-colors ${
                  isNavyHeader
                    ? 'bg-emerald-400 text-slate-950 hover:bg-emerald-300'
                    : 'bg-emerald-100 text-emerald-950 border border-emerald-300 hover:bg-emerald-200'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 animate-pulse" />
                <Globe className="w-3 h-3" />
                <span>Kết Nối Hosting (Online)</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleBlobDownload(
                    '/ta-xua-trip-chay-ngay.html',
                    'ta-xua-trip-chay-ngay.html',
                    'text/html;charset=utf-8'
                  )
                }
                className={`inline-flex items-center gap-1 font-extrabold px-2.5 py-0.5 rounded-full cursor-pointer transition-colors ${
                  isNavyHeader
                    ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                    : 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                }`}
              >
                <Download className="w-3 h-3" />
                <span>
                  {downloadingFile === 'ta-xua-trip-chay-ngay.html'
                    ? 'Đang tải...'
                    : '⚡ Tải File Chạy Ngay (.HTML)'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setHostingModalTab('download');
                  setIsDownloadModalOpen(true);
                }}
                className={`inline-flex items-center gap-1 font-bold hover:underline cursor-pointer ${
                  isNavyHeader ? 'text-emerald-300' : 'text-teal-700'
                }`}
              >
                <FolderArchive className="w-3 h-3" />
                <span>Tải Gói Dự Án (.ZIP)</span>
              </button>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="hidden sm:inline opacity-75">Chế độ xem:</span>
              <button
                type="button"
                onClick={() => {
                  setUserRole('traveler');
                  if (currentTab === 'partner' || currentTab === 'admin')
                    setCurrentTab('explore');
                }}
                className={`px-2 py-0.5 rounded-full font-semibold cursor-pointer ${
                  userRole === 'traveler'
                    ? isNavyHeader
                      ? 'bg-white/15 text-white'
                      : 'bg-slate-200 text-[#073161]'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                Du khách
              </button>
              <button
                type="button"
                onClick={() => {
                  setUserRole('partner');
                  setCurrentTab('partner');
                }}
                className={`px-2 py-0.5 rounded-full font-semibold inline-flex items-center gap-1 cursor-pointer ${
                  userRole === 'partner'
                    ? 'bg-teal-600 text-white'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                <Building2 className="w-3 h-3" />
                <span>Chủ cơ sở</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setUserRole('admin');
                  setCurrentTab('admin');
                }}
                className={`px-2 py-0.5 rounded-full font-semibold inline-flex items-center gap-1 cursor-pointer ${
                  userRole === 'admin'
                    ? 'bg-indigo-600 text-white'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                <ShieldCheck className="w-3 h-3" />
                <span>Admin</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <HostingModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        initialTab={hostingModalTab}
        onDownloadFile={handleBlobDownload}
        downloadingFile={downloadingFile}
      />
    </>
  );
};
