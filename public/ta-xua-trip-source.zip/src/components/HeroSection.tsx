import React, { useState } from 'react';
import {
  ShieldCheck,
  BookOpen,
  Heart,
  Building2,
  Package,
  Bus,
  Bike,
  Calendar,
  Users,
  CheckCircle2,
  CloudSun,
  Eye,
  Car,
  MapPin,
  Camera,
  MessageSquare,
  CalendarCheck,
  Search
} from 'lucide-react';
import { LocationArea } from '../types/index.ts';

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedArea: string;
  setSelectedArea: (area: string) => void;
  onlyCloudView: boolean;
  setOnlyCloudView: (val: boolean) => void;
  onlyAvailable: boolean;
  setOnlyAvailable: (val: boolean) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  onExploreClick: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  selectedArea,
  setSelectedArea,
  onlyCloudView,
  setOnlyCloudView,
  onlyAvailable,
  setOnlyAvailable,
  onExploreClick,
  onNavigateTab
}) => {
  const [checkInDate, setCheckInDate] = useState('2026-11-06');
  const [checkOutDate, setCheckOutDate] = useState('2026-11-08');
  const [guestCount, setGuestCount] = useState(2);
  const [roomCount, setRoomCount] = useState(1);
  const [bedViewFilter, setBedViewFilter] = useState(false);
  const [carAccessFilter, setCarAccessFilter] = useState(false);

  const areas: (LocationArea | 'all')[] = [
    'all',
    'Đỉnh Gió',
    'Sống Lưng Khủng Long',
    'Khe Cải',
    'Trung Tâm Tà Xùa',
    'Mống Vàng',
    'Thảo Nguyên',
    'Bắc Yên'
  ];

  const handleSearchSubmit = () => {
    onExploreClick();
    const el = document.getElementById('verified-listings-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative">
      {/* Deep Navy-to-Teal Hero Section matching https://taxuaslay1.vercel.app/ */}
      <div className="relative bg-gradient-to-br from-[#04244d] via-[#063366] to-[#084d5e] text-white pt-12 sm:pt-16 pb-36 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Subtle atmospheric radial glow */}
        <div
          className="pointer-events-none absolute -top-24 right-0 w-[550px] h-[550px] rounded-full opacity-25 blur-3xl"
          style={{
            background: 'radial-gradient(circle, #0d9488 0%, transparent 70%)'
          }}
        />

        <div className="relative max-w-6xl mx-auto">
          {/* Giant Brand Title + Script Subtitle */}
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white uppercase leading-none">
              TÀ XÙA TRIP
            </h1>
            <p className="font-script text-4xl sm:text-5xl text-white/95 mt-1 mb-7 leading-tight">
              Đi thật. Biết trước.
            </p>

            <h2 className="text-xl sm:text-2xl font-extrabold text-white mb-2.5">
              Tà Xùa, trước khi bạn đến.
            </h2>
            <p className="text-sm sm:text-base text-slate-200/95 leading-relaxed mb-8 max-w-xl">
              Thông tin thật về nơi ở, hành trình và trải nghiệm — để bạn biết rõ trước khi lên đường.
            </p>

            {/* 3 Core Pillars: THẬT · HIỂU · TRỌN VẸN */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 max-w-xl">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-teal-500/20 border border-teal-400/50 flex items-center justify-center text-teal-300 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-extrabold uppercase tracking-wider text-white">
                    THẬT
                  </div>
                  <div className="text-xs text-slate-300">Phòng thật, thông tin thật</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-teal-500/20 border border-teal-400/50 flex items-center justify-center text-teal-300 shrink-0">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-extrabold uppercase tracking-wider text-white">
                    HIỂU
                  </div>
                  <div className="text-xs text-slate-300">Biết rõ trước khi chọn</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-teal-500/20 border border-teal-400/50 flex items-center justify-center text-teal-300 shrink-0">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-extrabold uppercase tracking-wider text-white">
                    TRỌN VẸN
                  </div>
                  <div className="text-xs text-slate-300">Kết nối cả chuyến đi</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating White Search Console Card overlapping Hero & Light Canvas */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 relative z-20">
        <div className="bg-white rounded-[28px] shadow-[0_22px_50px_rgba(7,49,97,0.12)] border border-slate-200/90 overflow-hidden">
          {/* Top Service Tabs Row */}
          <div className="flex items-center border-b border-slate-200/80 overflow-x-auto no-scrollbar bg-slate-50/50">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`relative flex items-center gap-2 px-6 py-4 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === 'all' || selectedCategory === 'homestay'
                  ? 'bg-[#073161] text-white'
                  : 'text-slate-600 hover:text-[#073161]'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Lưu trú</span>
              {(selectedCategory === 'all' || selectedCategory === 'homestay') && (
                <span className="absolute bottom-0 left-3 right-3 h-1 bg-amber-400 rounded-t-full" />
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                setSelectedCategory('tour');
                handleSearchSubmit();
              }}
              className={`flex items-center gap-2 px-5 py-4 text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === 'tour'
                  ? 'bg-[#073161] text-white'
                  : 'text-slate-500 hover:text-[#073161]'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Combo & Trekking</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 border border-slate-200">
                Thẩm định
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onNavigateTab) onNavigateTab('bus');
              }}
              className="flex items-center gap-2 px-5 py-4 text-xs sm:text-sm font-semibold text-slate-500 hover:text-[#073161] whitespace-nowrap transition-colors cursor-pointer"
            >
              <Bus className="w-4 h-4" />
              <span>Xe khách</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                Đón dọc tuyến
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setSelectedCategory('motorbike');
                handleSearchSubmit();
              }}
              className={`flex items-center gap-2 px-5 py-4 text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === 'motorbike'
                  ? 'bg-[#073161] text-white'
                  : 'text-slate-500 hover:text-[#073161]'
              }`}
            >
              <Bike className="w-4 h-4" />
              <span>Xe máy</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                Tà Xùa Biker
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onNavigateTab) onNavigateTab('map');
              }}
              className="flex items-center gap-2 px-5 py-4 text-xs sm:text-sm font-semibold text-teal-700 hover:text-teal-800 whitespace-nowrap transition-colors cursor-pointer ml-auto"
            >
              <MapPin className="w-4 h-4" />
              <span>Bản đồ tọa độ săn mây →</span>
            </button>
          </div>

          {/* Main 5-Column Booking & Search Inputs */}
          <div className="p-5 sm:p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 items-center">
              {/* Check-in Date */}
              <div className="lg:col-span-3 sm:border-r border-slate-200/80 sm:pr-4">
                <label className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-700" />
                  <span>NHẬN PHÒNG</span>
                </label>
                <input
                  type="date"
                  value={checkInDate}
                  onChange={(e) => setCheckInDate(e.target.value)}
                  className="w-full text-sm font-bold text-[#073161] bg-transparent focus:outline-none cursor-pointer"
                />
              </div>

              {/* Check-out Date */}
              <div className="lg:col-span-3 lg:border-r border-slate-200/80 lg:pr-4">
                <label className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-700" />
                  <span>TRẢ PHÒNG</span>
                </label>
                <input
                  type="date"
                  value={checkOutDate}
                  onChange={(e) => setCheckOutDate(e.target.value)}
                  className="w-full text-sm font-bold text-[#073161] bg-transparent focus:outline-none cursor-pointer"
                />
              </div>

              {/* Guests Count */}
              <div className="lg:col-span-2 sm:border-r border-slate-200/80 sm:pr-4">
                <label className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  <Users className="w-3.5 h-3.5 text-teal-700" />
                  <span>SỐ KHÁCH</span>
                </label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={guestCount}
                  onChange={(e) => setGuestCount(Math.max(1, Number(e.target.value)))}
                  aria-label="Số khách"
                  className="w-full text-sm font-bold text-[#073161] bg-transparent focus:outline-none"
                />
              </div>

              {/* Rooms / Area Selector */}
              <div className="lg:col-span-2 lg:border-r border-slate-200/80 lg:pr-4">
                <label className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  <Building2 className="w-3.5 h-3.5 text-teal-700" />
                  <span>SỐ PHÒNG / KHU VỰC</span>
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={selectedArea}
                    onChange={(e) => setSelectedArea(e.target.value)}
                    aria-label="Chọn khu vực Tà Xùa"
                    className="w-full text-sm font-bold text-[#073161] bg-transparent focus:outline-none cursor-pointer truncate"
                  >
                    <option value="all">{roomCount} phòng · Toàn Tà Xùa</option>
                    {areas
                      .filter((a) => a !== 'all')
                      .map((area) => (
                        <option key={area} value={area}>
                          {area}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Primary Search Button */}
              <div className="lg:col-span-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleSearchSubmit}
                  className="w-full bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold text-sm py-3.5 px-6 rounded-full shadow-md transition-all cursor-pointer whitespace-nowrap"
                >
                  Tìm phòng
                </button>
              </div>
            </div>

            {/* Bottom Interest Filter Chips + Quick Keyword Input */}
            <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-[#073161] mr-1">Bạn quan tâm:</span>

                <button
                  type="button"
                  onClick={() => setOnlyAvailable(!onlyAvailable)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    onlyAvailable
                      ? 'bg-[#073161] text-white border-[#073161]'
                      : 'bg-white hover:bg-slate-50 text-[#073161] border-slate-200'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                  <span>Đã thẩm định</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOnlyCloudView(!onlyCloudView)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    onlyCloudView
                      ? 'bg-[#073161] text-white border-[#073161]'
                      : 'bg-white hover:bg-slate-50 text-[#073161] border-slate-200'
                  }`}
                >
                  <CloudSun className="w-3.5 h-3.5 text-teal-600" />
                  <span>Săn mây</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setBedViewFilter(!bedViewFilter);
                    setOnlyCloudView(!bedViewFilter);
                  }}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    bedViewFilter
                      ? 'bg-[#073161] text-white border-[#073161]'
                      : 'bg-white hover:bg-slate-50 text-[#073161] border-slate-200'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5 text-teal-600" />
                  <span>View từ giường</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCarAccessFilter(!carAccessFilter);
                    if (!carAccessFilter) {
                      setSelectedArea('Đỉnh Gió');
                    } else {
                      setSelectedArea('all');
                    }
                  }}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    carAccessFilter
                      ? 'bg-[#073161] text-white border-[#073161]'
                      : 'bg-white hover:bg-slate-50 text-[#073161] border-slate-200'
                  }`}
                >
                  <Car className="w-3.5 h-3.5 text-teal-600" />
                  <span>Ô tô vào được</span>
                </button>
              </div>

              {/* Compact keyword search input */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tìm tên homestay, khu vực..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-full pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#073161]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Pillar Verification Strip directly under Search Card (matching ref-hero.png) */}
      <div className="bg-white border-b border-slate-200/80 pt-10 pb-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center justify-center gap-2.5 text-xs sm:text-sm font-bold text-[#073161]">
            <span className="w-8 h-8 rounded-full bg-teal-50 border border-teal-200/70 flex items-center justify-center text-teal-700 shrink-0">
              <MapPin className="w-4 h-4" />
            </span>
            <span>Thẩm định tại chỗ</span>
          </div>

          <div className="flex items-center justify-center gap-2.5 text-xs sm:text-sm font-bold text-[#073161]">
            <span className="w-8 h-8 rounded-full bg-teal-50 border border-teal-200/70 flex items-center justify-center text-teal-700 shrink-0">
              <Camera className="w-4 h-4" />
            </span>
            <span>Video / ảnh 360°</span>
          </div>

          <div className="flex items-center justify-center gap-2.5 text-xs sm:text-sm font-bold text-[#073161]">
            <span className="w-8 h-8 rounded-full bg-teal-50 border border-teal-200/70 flex items-center justify-center text-teal-700 shrink-0">
              <MessageSquare className="w-4 h-4" />
            </span>
            <span>Nói cả ưu & nhược điểm</span>
          </div>

          <div className="flex items-center justify-center gap-2.5 text-xs sm:text-sm font-bold text-[#073161]">
            <span className="w-8 h-8 rounded-full bg-teal-50 border border-teal-200/70 flex items-center justify-center text-teal-700 shrink-0">
              <CalendarCheck className="w-4 h-4" />
            </span>
            <span>Dữ liệu có ngày xác minh</span>
          </div>
        </div>
      </div>
    </div>
  );
};
