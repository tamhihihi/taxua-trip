import React from 'react';
import {
  Star,
  MapPin,
  Phone,
  MessageSquare,
  Heart,
  Eye,
  Car
} from 'lucide-react';
import { Listing } from '../types/index.ts';
import { formatVND } from '../utils/rules.ts';

interface ListingCardProps {
  listing: Listing;
  onSelect: (listing: Listing) => void;
  isSaved?: boolean;
  onToggleSave?: (id: string) => void;
}

export const ListingCard: React.FC<ListingCardProps> = ({
  listing,
  onSelect,
  isSaved = false,
  onToggleSave
}) => {
  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'homestay':
        return 'Lưu trú · Homestay';
      case 'bus':
        return 'Xe khách · Limousine';
      case 'coffee':
        return 'Cà phê · Điểm ngắm mây';
      case 'restaurant':
        return 'Ẩm thực bản địa';
      case 'motorbike':
        return 'Xe máy · Tà Xùa Biker';
      case 'tour':
        return 'Combo · Trekking';
      case 'photo':
        return 'Media · Chụp ảnh';
      case 'rescue':
        return 'Cứu hộ đèo 24/7';
      default:
        return 'Dịch vụ Tà Xùa';
    }
  };

  const getTierText = (tier: number) => {
    if (tier === 3) return 'Thẩm định tại chỗ · Cấp 3';
    if (tier === 2) return 'Đã xác minh · Cấp 2';
    return 'Hồ sơ cơ bản';
  };

  const firstRoom = listing.roomTypes?.[0];

  return (
    <article className="bg-white border border-slate-200/90 hover:border-[#073161]/40 rounded-3xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-200 flex flex-col group">
      {/* Image Container */}
      <div
        onClick={() => onSelect(listing)}
        className="relative h-52 w-full overflow-hidden bg-slate-100 cursor-pointer"
      >
        <img
          src={listing.coverImage}
          alt={listing.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />

        {/* Top Favorite Button */}
        <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between">
          <span className="text-[11px] font-bold tracking-wide text-white bg-[#073161]/90 backdrop-blur-xs px-3 py-1 rounded-full">
            {getTierText(listing.verificationTier)}
          </span>

          {onToggleSave && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave(listing.id);
              }}
              className="w-8 h-8 rounded-full bg-white/90 hover:bg-white flex items-center justify-center text-slate-700 shadow-xs transition-colors"
              aria-label={`Lưu ${listing.title} vào danh sách yêu thích`}
            >
              <Heart
                className={`w-4 h-4 ${
                  isSaved ? 'fill-rose-500 text-rose-500' : 'text-slate-600'
                }`}
              />
            </button>
          )}
        </div>

        {/* Bottom Scrim Metadata */}
        <div className="absolute bottom-3 left-3.5 right-3.5 flex items-center justify-between text-xs text-white/95 font-medium">
          <span>Xác minh: {listing.updatedCalendarDate}</span>
          <span>{getCategoryLabel(listing.category)}</span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between">
        <div>
          {/* Clean Unboxed Metadata Line */}
          <div className="flex items-center justify-between gap-2 text-xs text-slate-500 mb-2">
            <div className="flex items-center gap-1.5 font-semibold text-teal-700 truncate">
              <MapPin className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{listing.area}</span>
              <span aria-hidden="true">·</span>
              <span>{listing.hasCloudView ? 'Cloud View thật' : 'View bản làng'}</span>
            </div>

            <div className="flex items-center gap-1 font-bold text-[#073161] shrink-0 tabular-nums">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{listing.rating}</span>
              <span className="text-slate-400 font-normal">({listing.reviewCount})</span>
            </div>
          </div>

          {/* Primary Title */}
          <h3
            onClick={() => onSelect(listing)}
            className="text-lg font-extrabold text-[#073161] group-hover:text-teal-700 transition-colors line-clamp-1 cursor-pointer mb-2"
          >
            {listing.title}
          </h3>

          {/* Description */}
          <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed mb-3">
            {listing.description}
          </p>

          {/* Verified Highlight Tags */}
          {listing.tags && listing.tags.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 mb-3.5">
              {listing.tags.slice(0, 3).map((tag, idx) => (
                <span
                  key={idx}
                  className="text-[11px] font-semibold text-[#073161] bg-slate-100 border border-slate-200/80 px-2.5 py-0.5 rounded-lg"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Evidence Scope Summary Box matching taxuaslay1.vercel.app verification ethos */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 mb-4 space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-slate-600">
              <span className="inline-flex items-center gap-1.5 font-medium">
                <Eye className="w-3.5 h-3.5 text-teal-700" />
                <span>Góc nhìn / Phòng:</span>
              </span>
              <span className="font-bold text-[#073161] truncate max-w-[170px]">
                {firstRoom ? firstRoom.name : listing.hasCloudView ? 'View thung lũng mây' : 'Toàn cơ sở'}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span className="inline-flex items-center gap-1.5 font-medium">
                <Car className="w-3.5 h-3.5 text-teal-700" />
                <span>Đường vào & Tình trạng:</span>
              </span>
              <span className="font-semibold text-teal-700">
                {firstRoom
                  ? `Còn ${firstRoom.availableRooms}/${firstRoom.totalRooms} phòng`
                  : 'Đường bê tông / Xe máy & Ô tô'}
              </span>
            </div>
          </div>
        </div>

        {/* Public Contact & Action Footer */}
        <div className="pt-3 border-t border-slate-100 space-y-3">
          {/* Transparent Phone & Zalo */}
          <div className="flex items-center justify-between text-xs text-slate-600">
            <a
              href={`tel:${listing.phone.replace(/\s+/g, '')}`}
              className="inline-flex items-center gap-1.5 font-bold text-[#073161] hover:text-teal-700 transition-colors tabular-nums"
              title="Gọi điện trực tiếp cho cơ sở"
            >
              <Phone className="w-3.5 h-3.5 text-teal-700" />
              <span>{listing.phone}</span>
            </a>

            <a
              href={`https://zalo.me/${listing.zalo.replace(/\s+/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold text-teal-700 hover:text-teal-800 transition-colors"
              title="Nhắn tin Zalo trực tiếp"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Zalo chính chủ →</span>
            </a>
          </div>

          {/* Price & Primary Button */}
          <div className="flex items-center justify-between gap-3 pt-1">
            <div>
              <div className="text-[11px] text-slate-500 font-medium">Giá ghi nhận từ</div>
              <div className="text-base font-extrabold text-[#073161] tabular-nums">
                {listing.minPrice > 0 ? formatVND(listing.minPrice) : 'Hỗ trợ 24/7'}
                {listing.minPrice > 0 && (
                  <span className="text-xs font-normal text-slate-500"> / đêm</span>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={() => onSelect(listing)}
              className="bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold text-xs px-4 py-2.5 rounded-full transition-colors cursor-pointer whitespace-nowrap"
            >
              Xem bằng chứng & Đặt →
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};
