/**
 * Business and Domain Rules for Tà Xùa Trip
 */

export interface CloudProbabilityParams {
  humidity: number; // in percent (e.g. 88)
  windSpeed: number; // in km/h (e.g. 8)
  tempDiff: number; // temperature difference between day and night in Celsius (e.g. 10)
}

/**
 * Tính xác suất xuất hiện biển mây Tà Xùa dựa trên công thức khí tượng:
 * - Độ ẩm cao (>80%) làm tăng xác suất mây
 * - Gió êm (<15km/h) giữ mây đọng lại trong thung lũng
 * - Chênh lệch nhiệt độ ngày & đêm lớn (>8°C) ngưng tụ hơi nước
 */
export function calculateCloudProbability(params: CloudProbabilityParams): { score: number; verdict: string } {
  const { humidity, windSpeed, tempDiff } = params;
  let score = 20; // base score

  // Humidity score
  if (humidity >= 90) score += 35;
  else if (humidity >= 80) score += 25;
  else if (humidity >= 70) score += 15;
  else score += 5;

  // Wind speed score
  if (windSpeed <= 10) score += 30;
  else if (windSpeed <= 18) score += 20;
  else if (windSpeed <= 25) score += 10;
  else score -= 10; // high wind blows clouds away

  // Temperature inversion / difference
  if (tempDiff >= 9) score += 20;
  else if (tempDiff >= 6) score += 12;
  else score += 5;

  // Clamp 5 - 98
  score = Math.max(5, Math.min(98, score));

  let verdict = 'Mây thưa - Nắng sớm';
  if (score >= 85) verdict = 'Biển mây dày đặc ngập thung lũng';
  else if (score >= 70) verdict = 'Mây luồn bồng bềnh cuộn sóng';
  else if (score >= 50) verdict = 'Mây rải rác - Đón hoàng hôn đẹp';

  return { score, verdict };
}

/**
 * Tính giờ đón dự kiến dựa trên giờ xuất bến và độ lệch phút tại điểm đón
 */
export function estimatePickupTime(departureTime: string, minuteOffset: number): string {
  const [hourStr, minStr] = departureTime.split(':');
  const h = parseInt(hourStr, 10);
  const m = parseInt(minStr, 10);
  if (isNaN(h) || isNaN(m)) return departureTime;

  const totalMin = (h * 60 + m + minuteOffset) % (24 * 60);
  const newH = Math.floor(totalMin / 60);
  const newM = totalMin % 60;

  return `${String(newH).padStart(2, '0')}:${String(newM).padStart(2, '0')}`;
}

/**
 * Quyết định tính phí 50.000đ từ nhà cung cấp:
 * Theo mục 2 & 11 trong kế hoạch: Chỉ thu khi booking 'completed', kiểm soát bằng cờ billing_enabled
 */
export function calculatePlatformFee(bookingStatus: string, billingEnabled: boolean): number {
  if (bookingStatus !== 'completed') return 0;
  if (!billingEnabled) return 0;
  return 50000;
}

/**
 * Tính điểm "Mây" cho thành viên:
 * Mỗi booking hoàn tất được thưởng điểm, viết review xác thực được thưởng thêm
 */
export function calculateMemberPoints(bookingAmount: number, isVerifiedReview = false): number {
  if (bookingAmount <= 0) return 0;
  // 100.000đ = 10 điểm Mây, tối thiểu 30 điểm cho 1 booking
  const basePoints = Math.max(30, Math.floor(bookingAmount / 100000) * 10);
  const reviewBonus = isVerifiedReview ? 50 : 0;
  return basePoints + reviewBonus;
}

/**
 * Định dạng tiền tệ Việt Nam (VNĐ)
 */
export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Tính khoảng cách đường đèo ước tính (km) giữa 2 tọa độ GPS (nhân hệ số quanh co đèo núi 1.35x)
 */
export function calculateDistanceKm(
  coord1: { lat: number; lng: number },
  coord2: { lat: number; lng: number }
): number {
  const R = 6371; // Bán kính trái đất (km)
  const dLat = ((coord2.lat - coord1.lat) * Math.PI) / 180;
  const dLng = ((coord2.lng - coord1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((coord1.lat * Math.PI) / 180) *
      Math.cos((coord2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const straightKm = R * c;
  // Nhân hệ số đường đèo uốn lượn Tà Xùa (1.35)
  return Math.round(straightKm * 1.35 * 10) / 10;
}

/**
 * Ước tính thời gian di chuyển bằng xe máy trên đường đèo Tà Xùa (tốc độ TB 22km/h)
 */
export function estimateMountainTravelMinutes(distanceKm: number): number {
  if (distanceKm <= 0) return 0;
  return Math.max(2, Math.round((distanceKm / 22) * 60));
}

/**
 * Kiểm tra xem một đơn đặt phòng có đủ điều kiện để lại đánh giá hay không:
 * Chỉ cho phép khi trạng thái là 'completed' và chưa đánh giá
 */
export function canBookingLeaveReview(status: string, alreadyReviewed = false): boolean {
  return status === 'completed' && !alreadyReviewed;
}

/**
 * Tính toán điểm trung bình mới và tổng số lượt đánh giá sau khi thêm 1 đánh giá mới
 */
export function calculateUpdatedRating(
  currentRating: number,
  currentReviewCount: number,
  newStarRating: number
): { rating: number; reviewCount: number } {
  const clampedStars = Math.max(1, Math.min(5, Math.round(newStarRating)));
  const safeCount = Math.max(0, currentReviewCount);
  const nextCount = safeCount + 1;
  const totalScore = currentRating * safeCount + clampedStars;
  const nextRating = Math.round((totalScore / nextCount) * 100) / 100;
  return {
    rating: Math.max(1, Math.min(5, nextRating)),
    reviewCount: nextCount
  };
}

export type QuickSuggestionId =
  | 'cloud_bedroom'
  | 'car_parking'
  | 'quiet_retreat'
  | 'large_group';

export interface QuickSuggestionItem {
  id: QuickSuggestionId;
  label: string;
  subtitle: string;
}

export const QUICK_SUGGESTIONS: QuickSuggestionItem[] = [
  {
    id: 'cloud_bedroom',
    label: 'View mây phòng ngủ',
    subtitle: 'Ngắm biển mây thẳng từ giường'
  },
  {
    id: 'car_parking',
    label: 'Có chỗ đậu ô tô',
    subtitle: 'Đường rộng, bãi đỗ xe an toàn'
  },
  {
    id: 'quiet_retreat',
    label: 'Yên tĩnh tuyệt đối',
    subtitle: 'Tách biệt ồn ào, nghỉ dưỡng sâu'
  },
  {
    id: 'large_group',
    label: 'Phù hợp nhóm đông',
    subtitle: 'Phòng gia đình / nguyên căn ≥ 4 khách'
  }
];

/**
 * Kiểm tra xem một cơ sở lưu trú (homestay) có khớp với tiêu chí 'Gợi ý nhanh' hay không
 */
export function matchesQuickSuggestion(
  listing: {
    category: string;
    tags: string[];
    description?: string;
    roomTypes?: Array<{ capacity: number; viewType: string; amenities: string[] }>;
  },
  suggestionId: QuickSuggestionId
): boolean {
  if (listing.category !== 'homestay') return false;

  const lowerTags = listing.tags.map((t) => t.toLowerCase());
  const lowerDesc = (listing.description || '').toLowerCase();

  switch (suggestionId) {
    case 'cloud_bedroom':
      return (
        lowerTags.some(
          (t) =>
            t.includes('view mây phòng ngủ') ||
            t.includes('view biển mây') ||
            t.includes('săn mây 360')
        ) ||
        lowerDesc.includes('chân giường') ||
        Boolean(
          listing.roomTypes?.some(
            (r) =>
              r.viewType.toLowerCase().includes('biển mây') &&
              r.amenities.some((a) => a.toLowerCase().includes('kính'))
          )
        )
      );

    case 'car_parking':
      return (
        lowerTags.some(
          (t) => t.includes('có chỗ đậu ô tô') || t.includes('đậu ô tô') || t.includes('bãi đỗ xe')
        ) || lowerDesc.includes('đậu ô tô')
      );

    case 'quiet_retreat':
      return (
        lowerTags.some(
          (t) => t.includes('yên tĩnh tuyệt đối') || t.includes('yên tĩnh') || t.includes('bình yên')
        ) || lowerDesc.includes('yên tĩnh tuyệt đối')
      );

    case 'large_group':
      return (
        lowerTags.some(
          (t) => t.includes('phù hợp nhóm đông') || t.includes('nhóm đông') || t.includes('gia đình')
        ) || Boolean(listing.roomTypes?.some((r) => r.capacity >= 4))
      );

    default:
      return false;
  }
}

/**
 * Kiểm tra hai khoảng ngày lưu trú [startA, endA) và [startB, endB) có trùng đêm nghỉ hay không
 */
export function doDateRangesOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string
): boolean {
  if (!startA || !endA || !startB || !endB) return false;
  const effectiveEndA = endA === startA ? `${startA}T23:59:59` : endA;
  const effectiveEndB = endB === startB ? `${startB}T23:59:59` : endB;
  return startA < effectiveEndB && startB < effectiveEndA;
}

/**
 * Kiểm tra xem homestay có còn phòng trống trong khoảng ngày [checkIn, checkOut) hay không
 */
export function isHomestayAvailableInDateRange(
  listing: {
    id: string;
    category: string;
    roomTypes?: Array<{
      name: string;
      availableRooms: number;
      capacity: number;
      bookedDateRanges?: Array<{ checkIn: string; checkOut: string }>;
    }>;
  },
  checkIn: string,
  checkOut: string,
  bookings: Array<{
    listingId: string;
    roomName?: string;
    checkInDate: string;
    checkOutDate: string;
    status: string;
  }> = []
): {
  available: boolean;
  availableRoomsCount: number;
  matchingRoomNames: string[];
} {
  if (listing.category !== 'homestay' || !listing.roomTypes || listing.roomTypes.length === 0) {
    return { available: false, availableRoomsCount: 0, matchingRoomNames: [] };
  }
  if (!checkIn || !checkOut || checkIn > checkOut) {
    return { available: false, availableRoomsCount: 0, matchingRoomNames: [] };
  }

  let totalAvailableInRange = 0;
  const matchingRoomNames: string[] = [];

  for (const room of listing.roomTypes) {
    if (room.availableRooms <= 0) continue;

    // Kiểm tra lịch khóa phòng (bookedDateRanges) của hạng phòng
    const isBlockedBySchedule = Boolean(
      room.bookedDateRanges?.some((range) =>
        doDateRangesOverlap(checkIn, checkOut, range.checkIn, range.checkOut)
      )
    );
    if (isBlockedBySchedule) continue;

    // Đếm các đơn đặt phòng đang giữ chỗ (confirmed / checked_in) trùng khoảng ngày
    const overlappingBookingsCount = bookings.filter(
      (b) =>
        b.listingId === listing.id &&
        b.roomName === room.name &&
        (b.status === 'confirmed' || b.status === 'checked_in' || b.status === 'pending') &&
        doDateRangesOverlap(checkIn, checkOut, b.checkInDate, b.checkOutDate)
    ).length;

    const remainingForRoom = Math.max(0, room.availableRooms - overlappingBookingsCount);
    if (remainingForRoom > 0) {
      totalAvailableInRange += remainingForRoom;
      matchingRoomNames.push(room.name);
    }
  }

  return {
    available: totalAvailableInRange > 0,
    availableRoomsCount: totalAvailableInRange,
    matchingRoomNames
  };
}

/**
 * Che thông tin cá nhân nhạy cảm (SĐT, CCCD 12 số, Số tài khoản) trước khi tạo embedding AI
 * (Theo PDF 2 - Mục 4.4 & Sprint 12)
 */
export function maskSensitivePII(text: string): { maskedText: string; piiFound: string[] } {
  const piiFound: string[] = [];
  let maskedText = text;

  // 1. Mask CCCD 12 chữ số
  const cccdRegex = /\b\d{12}\b/g;
  const cccdMatches = maskedText.match(cccdRegex);
  if (cccdMatches) {
    piiFound.push(...cccdMatches.map(() => 'CCCD_12_SO'));
    maskedText = maskedText.replace(cccdRegex, '[ĐÃ_CHE_CCCD]');
  }

  // 2. Mask Số điện thoại Việt Nam (03, 05, 07, 08, 09 hoặc +84, có thể có dấu cách/chấm)
  const phoneRegex = /(?:\+84|0)(?:3|5|7|8|9)(?:[\s.-]*\d){8}\b/g;
  const phoneMatches = maskedText.match(phoneRegex);
  if (phoneMatches) {
    piiFound.push(...phoneMatches.map(() => 'SDT_CA_NHAN'));
    maskedText = maskedText.replace(phoneRegex, '[ĐÃ_CHE_SĐT]');
  }

  // 3. Mask Số tài khoản ngân hàng (9 - 14 chữ số đi kèm từ khóa stk/tài khoản)
  const bankRegex = /(?:stk|tài khoản|tai khoan|chuyển khoản)[:\s-]*(\d{8,14})\b/gi;
  if (bankRegex.test(maskedText)) {
    piiFound.push('SO_TAI_KHOAN');
    maskedText = maskedText.replace(bankRegex, 'STK: [ĐÃ_CHE_STK]');
  }

  return { maskedText, piiFound };
}

/**
 * Tạo mã băm nối chuỗi (chained hash) cho tin nhắn mức Bằng chứng (Evidence Tier)
 * (Theo PDF 2 - Mục 3.2, 4.2 & Sprint 6)
 */
export function computeMessageHash(
  prevHash: string,
  seq: number,
  senderId: string,
  body: string,
  createdAt: string
): string {
  const payload = `${prevHash}|${seq}|${senderId}|${body}|${createdAt}`;
  let h1 = 0xdeadbeef ^ payload.length;
  let h2 = 0x41c6ce57 ^ payload.length;
  for (let i = 0; i < payload.length; i++) {
    const ch = payload.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const hex1 = (h1 >>> 0).toString(16).padStart(8, '0');
  const hex2 = (h2 >>> 0).toString(16).padStart(8, '0');
  return `ev_${seq}_${hex1}${hex2}`;
}

/**
 * Kiểm tra tính toàn vẹn của chuỗi băm tin nhắn mức Bằng chứng (phát hiện sửa tay trong DB)
 * (Theo PDF 2 - Mục 9 Tiêu chí nghiệm thu)
 */
export function verifyEvidenceHashChain(
  messages: Array<{
    seq: number;
    senderId: string;
    body: string;
    createdAt: string;
    prevHash: string;
    hash: string;
  }>
): { valid: boolean; brokenAtSeq: number | null } {
  let expectedPrev = 'GENESIS_EVIDENCE_00000000';
  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    if (msg.seq !== i + 1) {
      return { valid: false, brokenAtSeq: msg.seq };
    }
    if (msg.prevHash !== expectedPrev) {
      return { valid: false, brokenAtSeq: msg.seq };
    }
    const recomputed = computeMessageHash(
      msg.prevHash,
      msg.seq,
      msg.senderId,
      msg.body,
      msg.createdAt
    );
    if (msg.hash !== recomputed) {
      return { valid: false, brokenAtSeq: msg.seq };
    }
    expectedPrev = msg.hash;
  }
  return { valid: true, brokenAtSeq: null };
}

/**
 * Lớp 1 - AI Kiểm duyệt tức thì & Chống Prompt Injection
 * (Theo PDF 2 - Mục 3.6, 4.4, 5 & Sprint 14)
 */
export function classifyChatMessageAI(body: string): {
  flagged: boolean;
  labels: string[];
  riskScore: number;
  reason: string;
} {
  const lower = body.toLowerCase();
  const labels: string[] = [];
  let riskScore = 0;
  const reasons: string[] = [];

  // 1. Phát hiện rủ chuyển khoản ngoài / đòi cọc riêng (lách bảo vệ sàn / lừa đảo)
  if (
    lower.includes('chuyển khoản ngoài') ||
    lower.includes('cọc riêng') ||
    lower.includes('ck trực tiếp') ||
    lower.includes('không qua web') ||
    lower.includes('cọc trước vào stk')
  ) {
    labels.push('OFF_PLATFORM_DEPOSIT_RISK');
    riskScore += 75;
    reasons.push('Dấu hiệu yêu cầu đặt cọc / chuyển khoản ngoài nền tảng');
  }

  // 2. Phát hiện tấn công Prompt Injection vào trợ lý AI
  if (
    lower.includes('bỏ qua hướng dẫn') ||
    lower.includes('ignore previous') ||
    lower.includes('system prompt') ||
    lower.includes('đọc tin nhắn của người khác') ||
    lower.includes('hoàn tiền ngay') ||
    lower.includes('đổi giá phòng thành 0')
  ) {
    labels.push('PROMPT_INJECTION_ATTEMPT');
    riskScore += 90;
    reasons.push('Phát hiện chỉ dẫn độc hại (Prompt Injection) cố vượt quyền truy cập hoặc ép hoàn tiền/đổi giá');
  }

  // 3. Phát hiện lộ thông tin nhạy cảm (CCCD / SĐT) trong phòng chưa duyệt
  const pii = maskSensitivePII(body);
  if (pii.piiFound.length > 0) {
    labels.push('PII_EXPOSED');
    riskScore += 40;
    reasons.push(`Chứa thông tin định danh cá nhân (${pii.piiFound.join(', ')})`);
  }

  riskScore = Math.min(100, riskScore);
  return {
    flagged: labels.length > 0,
    labels,
    riskScore,
    reason: reasons.join('; ') || 'An toàn'
  };
}

/**
 * Ma trận phân quyền trong Hệ thống Chat theo vai trò và mức lưu trữ
 * (Theo PDF 2 - Bảng Mục 3.4 & Sprint 8)
 */
export type ChatActorRole = 'member' | 'moderator' | 'room_owner' | 'admin' | 'ai';
export type ChatActionType =
  | 'send_message'
  | 'edit_or_delete_own'
  | 'pin_message'
  | 'hide_violation'
  | 'read_evidence_room'
  | 'export_conversation';

export function checkChatPermission(
  role: ChatActorRole,
  action: ChatActionType,
  context: {
    tier?: 'social' | 'evidence';
    isReadOnlyRoom?: boolean;
    minutesSinceSent?: number;
    isOwnRoom?: boolean;
    isMemberOfEvidenceRoom?: boolean;
    hasTicketAndAuditLog?: boolean;
    hasDualAdminApproval?: boolean;
  } = {}
): boolean {
  const {
    tier = 'social',
    isReadOnlyRoom = false,
    minutesSinceSent = 0,
    isOwnRoom = false,
    isMemberOfEvidenceRoom = false,
    hasTicketAndAuditLog = false,
    hasDualAdminApproval = false
  } = context;

  switch (action) {
    case 'send_message':
      if (role === 'member') return !isReadOnlyRoom;
      return true;

    case 'edit_or_delete_own':
      // Mức bằng chứng (evidence): KHÔNG UPDATE hoặc DELETE được tin (kể cả từ code ứng dụng)
      if (tier === 'evidence') return false;
      if (role === 'ai') return false;
      if (role === 'member') return minutesSinceSent <= 15;
      return true; // moderator, room_owner, admin trong mức social

    case 'pin_message':
      return role === 'moderator' || role === 'room_owner' || role === 'admin';

    case 'hide_violation':
      if (role === 'moderator' || role === 'admin') return true;
      if (role === 'room_owner') return isOwnRoom;
      return false; // member chỉ báo cáo, AI chỉ gắn cờ

    case 'read_evidence_room':
      if (role === 'member') return isMemberOfEvidenceRoom;
      if (role === 'admin') return hasTicketAndAuditLog;
      if (role === 'ai') return hasTicketAndAuditLog; // chỉ phần được cấp để tóm tắt khi có ticket
      return false; // moderator và chủ phòng kèo không đọc được phòng bằng chứng của người khác

    case 'export_conversation':
      if (role === 'member') return isMemberOfEvidenceRoom;
      if (role === 'admin') return hasDualAdminApproval;
      return false;

    default:
      return false;
  }
}

/**
 * Phân tích tin nhắn Zalo nhanh của Chủ cơ sở để cập nhật lịch trống tự động
 * Ví dụ: "Cuối tuần còn 2 phòng đôi" hoặc "Hôm nay hết phòng"
 * (Theo PDF 1 Mục 3 & PDF 3 Mục 5 Nhóm A)
 */
export function parseZaloAvailabilityCommand(message: string): {
  matched: boolean;
  availableCount: number | null;
  roomKeyword: string | null;
} {
  const clean = message.trim().toLowerCase();
  if (!clean) return { matched: false, availableCount: null, roomKeyword: null };

  if (clean.includes('hết phòng') || clean.includes('đóng phòng') || clean.includes('còn 0 phòng')) {
    return {
      matched: true,
      availableCount: 0,
      roomKeyword: clean.includes('bungalow')
        ? 'bungalow'
        : clean.includes('đôi')
        ? 'đôi'
        : clean.includes('kính')
        ? 'kính'
        : 'tất cả'
    };
  }

  const match = clean.match(/còn\s+(\d+)\s*phòng\s*([a-zA-ZÀ-ỹ0-9\s]*)/i);
  if (match) {
    const count = parseInt(match[1], 10);
    const keyword = (match[2] || '').trim() || 'tiêu chuẩn';
    return {
      matched: true,
      availableCount: isNaN(count) ? null : count,
      roomKeyword: keyword
    };
  }

  return { matched: false, availableCount: null, roomKeyword: null };
}

/**
 * Tạo liên kết theo dõi nguồn (UTM) từ các kênh cộng đồng ngoài (Zalo OA, FB Group, TikTok, QR Offline) về Website
 * (Theo PDF 1 - Mục 2, 7 & 13)
 */
export function buildCommunityUtmUrl(
  baseUrl: string,
  channel: 'zalo_oa' | 'zalo_group' | 'fb_page' | 'fb_group' | 'tiktok' | 'qr_offline',
  campaign: string
): string {
  const cleanBase = baseUrl.replace(/\/+$/, '');
  const cleanCampaign =
    campaign
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9-_]/g, '_')
      .replace(/_+/g, '_') || 'ta_xua_community';

  const mediumMap: Record<typeof channel, string> = {
    zalo_oa: 'oa_broadcast',
    zalo_group: 'trip_chat_group',
    fb_page: 'social_page',
    fb_group: 'community_group',
    tiktok: 'short_video',
    qr_offline: 'homestay_standee_qr'
  };

  return `${cleanBase}/?utm_source=${channel}&utm_medium=${mediumMap[channel]}&utm_campaign=${cleanCampaign}`;
}





