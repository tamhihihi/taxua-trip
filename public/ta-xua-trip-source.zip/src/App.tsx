import React, { useState } from 'react';
import {
  INITIAL_LISTINGS,
  BUS_TRIPS,
  CLOUD_FORECASTS,
  COMMUNITY_POSTS,
  INITIAL_BOOKINGS,
  INITIAL_REVIEWS,
  INITIAL_USER_PROFILE,
  INITIAL_PARTNER_WALLET,
  CLOUD_LANDMARKS
} from './data/mockData.ts';
import {
  Listing,
  Booking,
  Review,
  UserRole,
  CommunityPost,
  VerificationTier
} from './types/index.ts';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { ListingCard } from './components/ListingCard.tsx';
import { ListingDetailModal } from './components/ListingDetailModal.tsx';
import { BusBookingModal } from './components/BusBookingModal.tsx';
import { CloudForecastWidget } from './components/CloudForecastWidget.tsx';
import { AIItineraryGenerator } from './components/AIItineraryGenerator.tsx';
import { CommunitySection } from './components/CommunitySection.tsx';
import { PartnerDashboard } from './components/PartnerDashboard.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { SosModal } from './components/SosModal.tsx';
import { BookingSuccessModal } from './components/BookingSuccessModal.tsx';
import { PointsModal } from './components/PointsModal.tsx';
import { InteractiveMapSection } from './components/InteractiveMapSection.tsx';
import {
  calculateMemberPoints,
  calculateUpdatedRating,
  QUICK_SUGGESTIONS,
  matchesQuickSuggestion,
  QuickSuggestionId,
  isHomestayAvailableInDateRange
} from './utils/rules.ts';
import {
  Bus,
  CloudSun,
  Sparkles,
  CheckCircle2,
  ShieldCheck,
  Camera,
  Info,
  Compass,
  BedDouble,
  Bike,
  Package,
  Eye,
  Route,
  SlidersHorizontal,
  Calendar,
  Users,
  MessageCircle,
  X,
  Mountain,
  Car,
  VolumeX
} from 'lucide-react';

export default function App() {
  // Navigation & Role State
  const [currentTab, setCurrentTab] = useState<string>('explore');
  const [userRole, setUserRole] = useState<UserRole>('traveler');

  // Application Data State
  const [listings, setListings] = useState<Listing[]>(INITIAL_LISTINGS);
  const [trips] = useState(BUS_TRIPS);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(COMMUNITY_POSTS);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [userProfile, setUserProfile] = useState(INITIAL_USER_PROFILE);
  const [partnerWallet, setPartnerWallet] = useState(INITIAL_PARTNER_WALLET);
  const [billingEnabled, setBillingEnabled] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedArea, setSelectedArea] = useState('all');
  const [onlyCloudView, setOnlyCloudView] = useState(false);
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState('recommended');
  const [selectedQuickSuggestions, setSelectedQuickSuggestions] = useState<QuickSuggestionId[]>([]);

  const handleToggleQuickSuggestion = (suggestionId: QuickSuggestionId) => {
    setSelectedQuickSuggestions((prev) => {
      const exists = prev.includes(suggestionId);
      const next = exists ? prev.filter((id) => id !== suggestionId) : [...prev, suggestionId];
      if (next.length > 0 && selectedCategory !== 'all' && selectedCategory !== 'homestay') {
        setSelectedCategory('homestay');
      }
      return next;
    });
  };

  // Stay Page Specific Filters
  const [stayViewDirection, setStayViewDirection] = useState('all');
  const [stayCarAccess, setStayCarAccess] = useState('all');
  const [stayCheckIn, setStayCheckIn] = useState('2026-11-06');
  const [stayCheckOut, setStayCheckOut] = useState('2026-11-08');
  const [stayFilterByAvailableDates, setStayFilterByAvailableDates] = useState(true);
  const [stayAdults, setStayAdults] = useState(2);
  const [stayChildren, setStayChildren] = useState(0);

  // Floating AI Assistant Greeting State
  const [showAiGreeting, setShowAiGreeting] = useState(true);

  // Modals
  const [selectedListingDetail, setSelectedListingDetail] = useState<Listing | null>(null);
  const [isBusModalOpen, setIsBusModalOpen] = useState(false);
  const [isSosModalOpen, setIsSosModalOpen] = useState(false);
  const [isPointsModalOpen, setIsPointsModalOpen] = useState(false);
  const [activeSuccessBooking, setActiveSuccessBooking] = useState<Booking | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Toggle Favorite
  const handleToggleSave = (id: string) => {
    setUserProfile((prev) => {
      const isSaved = prev.savedListings.includes(id);
      const nextSaved = isSaved
        ? prev.savedListings.filter((item) => item !== id)
        : [...prev.savedListings, id];
      showToast(isSaved ? 'Đã bỏ lưu cơ sở' : 'Đã lưu cơ sở vào danh sách yêu thích!');
      return { ...prev, savedListings: nextSaved };
    });
  };

  // Filter listings
  const filteredListings = listings
    .filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
      if (selectedArea !== 'all' && item.area !== selectedArea) return false;
      if (onlyCloudView && !item.hasCloudView) return false;
      if (onlyAvailable && item.roomTypes) {
        const hasFreeRooms = item.roomTypes.some((r) => r.availableRooms > 0);
        if (!hasFreeRooms) return false;
      }
      if (selectedQuickSuggestions.length > 0) {
        const matchesAllQuick = selectedQuickSuggestions.every((qid) =>
          matchesQuickSuggestion(item, qid)
        );
        if (!matchesAllQuick) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchArea = item.area.toLowerCase().includes(q);
        const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));
        if (!matchTitle && !matchArea && !matchTags) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'price_asc') return a.minPrice - b.minPrice;
      if (sortBy === 'price_desc') return b.minPrice - a.minPrice;
      return b.verificationTier - a.verificationTier;
    });

  // Dedicated /stay Filtered Homestays (with 'Lọc theo ngày trống')
  const stayFilteredListings = listings
    .filter((item) => {
      if (item.category !== 'homestay') return false;
      if (selectedArea !== 'all' && item.area !== selectedArea) return false;
      if (onlyCloudView && !item.hasCloudView) return false;

      if (stayViewDirection === 'mountain' && !item.hasCloudView) return false;
      if (
        stayViewDirection === 'valley' &&
        !item.roomTypes?.some((r) => r.viewType.toLowerCase().includes('thung lũng'))
      ) {
        return false;
      }

      if (
        stayCarAccess === 'yes' &&
        !item.tags.some((t) => t.toLowerCase().includes('ô tô'))
      ) {
        return false;
      }

      if (stayFilterByAvailableDates) {
        const availability = isHomestayAvailableInDateRange(
          item,
          stayCheckIn,
          stayCheckOut,
          bookings
        );
        if (!availability.available) return false;
      } else if (onlyAvailable && item.roomTypes) {
        const hasFreeRooms = item.roomTypes.some((r) => r.availableRooms > 0);
        if (!hasFreeRooms) return false;
      }

      return true;
    })
    .sort((a, b) => b.verificationTier - a.verificationTier);

  // Booking completion handler
  const handleBookingSuccess = (newBooking: Booking) => {
    setBookings((prev) => [newBooking, ...prev]);
    const earnedPoints = calculateMemberPoints(newBooking.totalAmount);
    setUserProfile((prev) => ({
      ...prev,
      cloudPoints: prev.cloudPoints + earnedPoints,
      bookingHistory: [newBooking, ...prev.bookingHistory]
    }));

    setListings((prev) =>
      prev.map((l) => {
        if (l.id === newBooking.listingId) {
          return {
            ...l,
            stats: {
              ...l.stats,
              bookingsCount: l.stats.bookingsCount + 1
            }
          };
        }
        return l;
      })
    );

    setSelectedListingDetail(null);
    setIsBusModalOpen(false);
    setActiveSuccessBooking(newBooking);
  };

  // Partner dashboard handlers
  const handleUpdateAvailability = (roomId: string, newAvailable: number) => {
    setListings((prev) =>
      prev.map((listing) => {
        if (listing.roomTypes) {
          return {
            ...listing,
            roomTypes: listing.roomTypes.map((r) =>
              r.id === roomId ? { ...r, availableRooms: newAvailable } : r
            ),
            updatedCalendarDate: new Date().toISOString().slice(0, 10)
          };
        }
        return listing;
      })
    );
    showToast('Đã cập nhật số phòng trống thành công!');
  };

  const handleConfirmBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'confirmed' } : b))
    );
    showToast('Đã xác nhận đơn đặt phòng!');
  };

  const handleCheckInBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'checked_in' } : b))
    );
    showToast('Khách đã Check-in tại quầy thành công!');
  };

  const handleCompleteBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id === bookingId) {
          return {
            ...b,
            status: 'completed',
            feeCharged: billingEnabled
          };
        }
        return b;
      })
    );

    setPartnerWallet((prev) => ({
      ...prev,
      completedBookingsCount: prev.completedBookingsCount + 1,
      balance: billingEnabled ? Math.max(0, prev.balance - 50000) : prev.balance,
      pendingFeeTotal: billingEnabled ? prev.pendingFeeTotal : prev.pendingFeeTotal + 50000
    }));

    showToast('Đã hoàn tất lưu trú! Bạn đã có thể để lại đánh giá xác thực.');
  };

  // Add verified review from a completed booking
  const handleAddReview = (newReview: Review, bookingId?: string) => {
    setReviews((prev) => [newReview, ...prev]);

    if (bookingId) {
      setBookings((prev) =>
        prev.map((b) => (b.id === bookingId ? { ...b, reviewed: true } : b))
      );
    }

    setListings((prev) =>
      prev.map((l) => {
        if (l.id === newReview.listingId) {
          const updated = calculateUpdatedRating(l.rating, l.reviewCount, newReview.rating);
          return {
            ...l,
            rating: updated.rating,
            reviewCount: updated.reviewCount
          };
        }
        return l;
      })
    );

    setSelectedListingDetail((prev) => {
      if (!prev || prev.id !== newReview.listingId) return prev;
      const updated = calculateUpdatedRating(
        prev.rating,
        prev.reviewCount,
        newReview.rating
      );
      return {
        ...prev,
        rating: updated.rating,
        reviewCount: updated.reviewCount
      };
    });

    setUserProfile((prev) => ({
      ...prev,
      cloudPoints: prev.cloudPoints + 50
    }));

    showToast('Đã đăng đánh giá xác thực thành công! (+50 Điểm Mây)');
  };

  // Admin handlers
  const handleToggleBilling = () => {
    setBillingEnabled(!billingEnabled);
    showToast(
      !billingEnabled
        ? 'Đã BẬT cờ thu phí 50.000đ/booking!'
        : 'Đã TẮT thu phí - Chế độ Beta miễn phí'
    );
  };

  const handleUpdateTier = (listingId: string, newTier: VerificationTier) => {
    setListings((prev) =>
      prev.map((l) => (l.id === listingId ? { ...l, verificationTier: newTier } : l))
    );
    showToast(`Đã cập nhật huy hiệu Cấp ${newTier} cho cơ sở!`);
  };

  const handleApproveListing = (listingId: string) => {
    setListings((prev) =>
      prev.map((l) => (l.id === listingId ? { ...l, status: 'approved' } : l))
    );
    showToast('Đã phê duyệt cơ sở hiển thị công khai!');
  };

  const handleRejectListing = (listingId: string) => {
    setListings((prev) =>
      prev.map((l) => (l.id === listingId ? { ...l, status: 'rejected' } : l))
    );
    showToast('Đã từ chối cơ sở');
  };

  const handleAddCommunityPost = (post: CommunityPost) => {
    setCommunityPosts((prev) => [post, ...prev]);
    showToast('Đăng bài lên cộng đồng thành công!');
  };

  const handleRedeemReward = (title: string, cost: number) => {
    if (userProfile.cloudPoints >= cost) {
      setUserProfile((prev) => ({ ...prev, cloudPoints: prev.cloudPoints - cost }));
      setIsPointsModalOpen(false);
      showToast(`Đổi thành công: ${title}! Mã ưu đãi đã được lưu vào hồ sơ.`);
    }
  };

  const partnerListing = listings[0];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans selection:bg-[#073161] selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-6 z-50 bg-[#073161] text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 border border-white/15">
          <CheckCircle2 className="w-4 h-4 text-teal-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userRole={userRole}
        setUserRole={setUserRole}
        cloudPoints={userProfile.cloudPoints}
        onOpenSos={() => setIsSosModalOpen(true)}
        onOpenPointsModal={() => setIsPointsModalOpen(true)}
        savedCount={userProfile.savedListings.length}
        onOpenSavedModal={() => {}}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentTab === 'explore' && (
          <>
            {/* 1. Hero Section + Floating White Search Card + 4-Pillar Trust Bar */}
            <HeroSection
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              selectedArea={selectedArea}
              setSelectedArea={setSelectedArea}
              onlyCloudView={onlyCloudView}
              setOnlyCloudView={setOnlyCloudView}
              onlyAvailable={onlyAvailable}
              setOnlyAvailable={setOnlyAvailable}
              sortBy={sortBy}
              setSortBy={setSortBy}
              onExploreClick={() => {}}
              onNavigateTab={(tab) => setCurrentTab(tab)}
            />

            {/* 2. Section: VÌ SAO CHỌN CHÚNG TÔI? (matching ref-mid1.png) */}
            <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#f8fafc]">
              <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                <div className="lg:col-span-5">
                  <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-3">
                    VÌ SAO CHỌN CHÚNG TÔI?
                  </p>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161] leading-[1.15] tracking-tight">
                    Quyết định dễ hơn khi thông tin được tách rõ.
                  </h2>
                </div>

                <div className="lg:col-span-7">
                  <div className="bg-white border border-slate-200/90 rounded-3xl p-7 sm:p-9 shadow-2xs">
                    <p className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed mb-4">
                      Một dòng “view núi” chưa cho bạn biết có nhìn thấy cảnh từ giường, góc nhìn có bị che, đường vào có khó, phòng có khớp ảnh hay dữ liệu còn mới không.
                    </p>
                    <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                      Chúng tôi kiểm tra và tách từng thông tin để bạn tự chọn phương án phù hợp, kể cả khi câu trả lời hiện tại là “Chưa xác minh”.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* 3. Section: CHÚNG TÔI LÀM GÌ KHÁC? (matching ref-mid1.png) */}
            <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white border-t border-slate-200/70">
              <div className="max-w-6xl mx-auto">
                <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-3">
                  CHÚNG TÔI LÀM GÌ KHÁC?
                </p>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161] leading-[1.15] tracking-tight max-w-2xl mb-10">
                  Bắt đầu từ bằng chứng, không bắt đầu từ lời quảng cáo.
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs flex flex-col justify-between">
                    <div>
                      <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-5">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <h3 className="text-base font-extrabold text-[#073161] uppercase tracking-tight mb-2">
                        THẨM ĐỊNH TẠI CHỖ
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        Ghi nhận đúng nơi, đúng loại phòng và đúng phạm vi.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs flex flex-col justify-between">
                    <div>
                      <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-5">
                        <Camera className="w-5 h-5" />
                      </div>
                      <h3 className="text-base font-extrabold text-[#073161] uppercase tracking-tight mb-2">
                        XEM TRƯỚC BẰNG 360°
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        Ảnh toàn cảnh được gắn nhãn phòng hoặc vị trí ngắm.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs flex flex-col justify-between">
                    <div>
                      <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-5">
                        <Info className="w-5 h-5" />
                      </div>
                      <h3 className="text-base font-extrabold text-[#073161] uppercase tracking-tight mb-2">
                        NÓI CẢ ĐIỂM CHƯA TỐT
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        Ưu điểm và điều cần lưu ý cùng xuất hiện khi có dữ liệu.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs flex flex-col justify-between">
                    <div>
                      <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-5">
                        <Compass className="w-5 h-5" />
                      </div>
                      <h3 className="text-base font-extrabold text-[#073161] uppercase tracking-tight mb-2">
                        CHỈ MỞ KHI CÓ DỮ LIỆU THẬT
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        Hệ thống tách biệt rõ Lưu trú, Bản đồ săn mây, Xe khách và Xe máy.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 4. Section: DỮ LIỆU THẬT ĐANG CÔNG KHAI — Homestay & phòng Tà Xùa đã thẩm định (matching ref-mid2.png) */}
            <section
              id="verified-listings-section"
              className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#f8fafc] border-t border-slate-200/70"
            >
              <div className="max-w-6xl mx-auto">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-2">
                      DỮ LIỆU THẬT ĐANG CÔNG KHAI
                    </p>
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161] tracking-tight">
                      Homestay & phòng Tà Xùa đã thẩm định
                    </h2>
                    <p className="text-sm text-slate-600 mt-2 max-w-2xl">
                      Chỉ hiển thị phòng và dịch vụ có hồ sơ Cloud View, số điện thoại & Zalo chính chủ công khai và ngày xác minh rõ ràng.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setCurrentTab('stay')}
                    className="text-sm font-extrabold text-[#073161] hover:text-teal-700 transition-colors self-start md:self-auto cursor-pointer whitespace-nowrap"
                  >
                    Xem toàn bộ Lưu trú ({listings.length}) →
                  </button>
                </div>

                {/* Thanh công cụ 'Gợi ý nhanh' (Quick Suggestions Toolbar) */}
                <div
                  id="quick-suggestions-toolbar"
                  aria-label="Thanh công cụ Gợi ý nhanh"
                  className="bg-white border border-slate-200/90 rounded-3xl p-4 sm:p-5 mb-5 shadow-2xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center justify-center w-7 h-7 rounded-xl bg-teal-50 text-teal-700">
                        <Sparkles className="w-4 h-4" />
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-extrabold uppercase tracking-wider text-[#073161]">
                            Gợi ý nhanh
                          </span>
                          <span className="text-[11px] font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full">
                            Tiêu chí Homestay Hot
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          Chạm để lọc nhanh danh sách homestay bên dưới theo nhu cầu thực tế của bạn
                        </p>
                      </div>
                    </div>

                    {selectedQuickSuggestions.length > 0 && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-teal-700">
                          Đang lọc {filteredListings.length} homestay phù hợp
                        </span>
                        <button
                          type="button"
                          onClick={() => setSelectedQuickSuggestions([])}
                          className="text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-full transition-colors cursor-pointer"
                        >
                          Bỏ lọc nhanh ({selectedQuickSuggestions.length})
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                    {QUICK_SUGGESTIONS.map((item) => {
                      const isActive = selectedQuickSuggestions.includes(item.id);
                      const matchCount = listings.filter((l) =>
                        matchesQuickSuggestion(l, item.id)
                      ).length;

                      const renderIcon = (id: QuickSuggestionId) => {
                        switch (id) {
                          case 'cloud_bedroom':
                            return <Eye className="w-4 h-4 shrink-0" />;
                          case 'car_parking':
                            return <Car className="w-4 h-4 shrink-0" />;
                          case 'quiet_retreat':
                            return <VolumeX className="w-4 h-4 shrink-0" />;
                          case 'large_group':
                            return <Users className="w-4 h-4 shrink-0" />;
                        }
                      };

                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleToggleQuickSuggestion(item.id)}
                          aria-pressed={isActive}
                          className={`group flex items-start justify-between gap-2 p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                            isActive
                              ? 'bg-[#073161] text-white border-[#073161] shadow-md'
                              : 'bg-[#f8fafc] hover:bg-white text-slate-800 border-slate-200/90 hover:border-[#073161]/40'
                          }`}
                        >
                          <div className="flex items-start gap-2.5 min-w-0">
                            <div
                              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                                isActive
                                  ? 'bg-white/15 text-teal-300'
                                  : 'bg-white text-[#073161] border border-slate-200/80 group-hover:text-teal-700'
                              }`}
                            >
                              {renderIcon(item.id)}
                            </div>
                            <div className="min-w-0">
                              <div
                                className={`text-xs font-extrabold truncate ${
                                  isActive ? 'text-white' : 'text-[#073161]'
                                }`}
                              >
                                {item.label}
                              </div>
                              <div
                                className={`text-[11px] truncate mt-0.5 ${
                                  isActive ? 'text-slate-200' : 'text-slate-500'
                                }`}
                              >
                                {item.subtitle}
                              </div>
                            </div>
                          </div>

                          <span
                            className={`text-[11px] font-extrabold px-2 py-0.5 rounded-full shrink-0 ${
                              isActive
                                ? 'bg-teal-500 text-slate-950'
                                : 'bg-white text-slate-600 border border-slate-200'
                            }`}
                          >
                            {matchCount}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Interactive Category Filter Segmented Control */}
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-6">
                  {[
                    { id: 'all', label: 'Tất cả hồ sơ công khai' },
                    { id: 'homestay', label: 'Lưu trú · Homestay' },
                    { id: 'coffee', label: 'Cà phê · Điểm ngắm mây' },
                    { id: 'restaurant', label: 'Ẩm thực bản địa' },
                    { id: 'motorbike', label: 'Xe máy · Tà Xùa Biker' },
                    { id: 'tour', label: 'Combo · Trekking' },
                    { id: 'rescue', label: 'Cứu hộ đèo 24/7' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        if (cat.id !== 'all' && cat.id !== 'homestay') {
                          setSelectedQuickSuggestions([]);
                        }
                      }}
                      className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
                        selectedCategory === cat.id
                          ? 'bg-[#073161] text-white border-[#073161] shadow-xs'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {filteredListings.length === 0 ? (
                  <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center max-w-2xl mx-auto shadow-2xs">
                    <h3 className="text-lg font-extrabold text-[#073161] mb-2">
                      Chưa có phòng Cloud View khớp điều kiện lọc hiện tại
                    </h3>
                    <p className="text-sm text-slate-600 mb-6">
                      Khi có hồ sơ thẩm định còn hiệu lực, phòng sẽ xuất hiện tại đây. Chúng tôi không tạo điểm hoặc thẻ mẫu giả định.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedCategory('all');
                        setSelectedArea('all');
                        setOnlyCloudView(false);
                        setOnlyAvailable(false);
                        setSelectedQuickSuggestions([]);
                      }}
                      className="px-6 py-2.5 rounded-full border border-slate-300 hover:border-[#073161] text-xs font-bold text-[#073161] transition-colors cursor-pointer"
                    >
                      Mở toàn bộ danh sách Lưu trú
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredListings.map((listing) => (
                      <ListingCard
                        key={listing.id}
                        listing={listing}
                        onSelect={(l) => setSelectedListingDetail(l)}
                        isSaved={userProfile.savedListings.includes(listing.id)}
                        onToggleSave={handleToggleSave}
                      />
                    ))}
                  </div>
                )}
              </div>
            </section>

            {/* 5. Interactive Map of Homestays & Cloud-Hunting Landmarks */}
            <InteractiveMapSection
              listings={filteredListings}
              landmarks={CLOUD_LANDMARKS}
              onSelectListing={(l) => setSelectedListingDetail(l)}
            />

            {/* 6. Section: MỘT CHUYẾN TÀ XÙA TRỌN VẸN — Mỗi dịch vụ đều nói rõ trạng thái (matching ref-mid2.png) */}
            <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white">
              <div className="max-w-6xl mx-auto">
                <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-3">
                  MỘT CHUYẾN TÀ XÙA TRỌN VẸN
                </p>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161] tracking-tight mb-10">
                  Mỗi dịch vụ đều nói rõ trạng thái.
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {/* Card 1: Lưu trú */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 flex flex-col justify-between shadow-2xs">
                    <div>
                      <div className="text-teal-700 mb-4">
                        <BedDouble className="w-6 h-6" />
                      </div>
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-teal-50 text-teal-800 mb-3">
                        Đang hoạt động
                      </span>
                      <h3 className="text-xl font-extrabold text-[#073161] mb-2">Lưu trú</h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                        Tìm theo phòng, ngày, bằng chứng, giá và tình trạng được ghi nhận.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('stay')}
                      className="text-xs font-extrabold text-[#073161] hover:text-teal-700 text-left cursor-pointer"
                    >
                      Tìm phòng →
                    </button>
                  </div>

                  {/* Card 2: Xe khách */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 flex flex-col justify-between shadow-2xs">
                    <div>
                      <div className="text-teal-700 mb-4">
                        <Bus className="w-6 h-6" />
                      </div>
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-teal-50 text-teal-800 mb-3">
                        Đang hoạt động
                      </span>
                      <h3 className="text-xl font-extrabold text-[#073161] mb-2">Xe khách</h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                        Lịch trình Limousine & Cabin đón dọc tuyến Hà Nội – Bắc Yên – Tà Xùa, chọn ghế trực quan.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('bus')}
                      className="text-xs font-extrabold text-[#073161] hover:text-teal-700 text-left cursor-pointer"
                    >
                      Xem lịch xe & đặt ghế →
                    </button>
                  </div>

                  {/* Card 3: Xe máy */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 flex flex-col justify-between shadow-2xs">
                    <div>
                      <div className="text-teal-700 mb-4">
                        <Bike className="w-6 h-6" />
                      </div>
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 mb-3">
                        Cần xác nhận
                      </span>
                      <h3 className="text-xl font-extrabold text-[#073161] mb-2">Xe máy</h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                        Xem thông tin công khai từ Tà Xùa Biker; giá và tình trạng thực tế được xác nhận thủ công.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedCategory('motorbike');
                        const el = document.getElementById('verified-listings-section');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-xs font-extrabold text-[#073161] hover:text-teal-700 text-left cursor-pointer"
                    >
                      Xem dịch vụ →
                    </button>
                  </div>

                  {/* Card 4: Combo & Lịch trình */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 flex flex-col justify-between shadow-2xs">
                    <div>
                      <div className="text-teal-700 mb-4">
                        <Package className="w-6 h-6" />
                      </div>
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 mb-3">
                        Tư vấn theo nhu cầu
                      </span>
                      <h3 className="text-xl font-extrabold text-[#073161] mb-2">Combo & Lịch trình</h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                        Gợi ý hành trình 2N1Đ / 3N2Đ tối ưu theo ngân sách và phương tiện di chuyển thực tế.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('itinerary')}
                      className="text-xs font-extrabold text-[#073161] hover:text-teal-700 text-left cursor-pointer"
                    >
                      Mở Trợ lý Lịch trình →
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* 7. Section: CÁCH CHÚNG TÔI THẨM ĐỊNH (matching ref-bottom.png) */}
            <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#f8fafc] border-t border-slate-200/70">
              <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Left Navy-to-Teal Feature Callout Box */}
                <div className="lg:col-span-5 bg-gradient-to-br from-[#042856] via-[#063a6e] to-[#0a6b6e] rounded-3xl p-8 sm:p-10 text-white flex flex-col justify-between shadow-lg">
                  <div>
                    <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-amber-400 mb-6">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-bold uppercase tracking-[0.14em] text-slate-200 mb-2">
                      CÁCH CHÚNG TÔI THẨM ĐỊNH
                    </p>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight mb-4">
                      Biết thông tin thuộc đúng phạm vi nào.
                    </h2>
                    <p className="text-sm text-slate-200 leading-relaxed mb-8">
                      Danh tính phòng, bằng chứng đúng phòng, Cloud View, đường vào, chất lượng và độ mới được giữ tách biệt.
                    </p>
                  </div>

                  <div>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('verified')}
                      className="bg-white hover:bg-slate-100 text-[#073161] font-extrabold text-xs sm:text-sm px-6 py-3.5 rounded-full transition-colors cursor-pointer"
                    >
                      Xem phương pháp thẩm định
                    </button>
                  </div>
                </div>

                {/* Right 2x3 Grid of Verification Scopes */}
                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    {
                      icon: <BedDouble className="w-5 h-5 text-teal-700" />,
                      title: 'Loại phòng / phòng mẫu',
                      desc: 'Phân biệt rõ ảnh đại diện hạng phòng với ảnh thực tế của từng căn.'
                    },
                    {
                      icon: <CheckCircle2 className="w-5 h-5 text-teal-700" />,
                      title: 'Phòng cụ thể / Room ID',
                      desc: 'Mỗi căn bungalow hoặc phòng kính có mã định danh và vị trí riêng.'
                    },
                    {
                      icon: <Eye className="w-5 h-5 text-teal-700" />,
                      title: 'View Thật & Cloud View',
                      desc: 'Ghi nhận góc nhìn từ giường ngủ, ban công và vật cản trước mặt.'
                    },
                    {
                      icon: <Route className="w-5 h-5 text-teal-700" />,
                      title: 'Đường vào đã thẩm định',
                      desc: 'Độ dốc, mặt đường bê tông/đất và khả năng ô tô 16 chỗ hoặc xe máy tiếp cận.'
                    },
                    {
                      icon: <Sparkles className="w-5 h-5 text-teal-700" />,
                      title: 'Chất lượng từng chiều',
                      desc: 'Bình nóng lạnh, sưởi ấm, cách âm, độ sạch và áp lực nước mùa lạnh.'
                    },
                    {
                      icon: <CloudSun className="w-5 h-5 text-teal-700" />,
                      title: 'Ngày xác minh & độ mới',
                      desc: 'Mọi dữ liệu đều đính kèm mốc thời gian kiểm tra thực địa gần nhất.'
                    }
                  ].map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-white border border-slate-200/90 rounded-3xl p-5 flex items-start gap-4 shadow-2xs"
                    >
                      <div className="w-11 h-11 rounded-2xl bg-teal-50 flex items-center justify-center shrink-0">
                        {item.icon}
                      </div>
                      <div>
                        <h3 className="text-sm sm:text-base font-extrabold text-[#073161] mb-1">
                          {item.title}
                        </h3>
                        <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 8. Section: CLOUD VIEW (matching ref-bottom.png & ref-footer.png) */}
            <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white border-t border-slate-200/70">
              <div className="max-w-6xl mx-auto">
                <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-3">
                  CLOUD VIEW
                </p>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161] tracking-tight mb-4">
                  Chất lượng góc nhìn, không phải dự báo thời tiết.
                </h2>
                <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed mb-8">
                  Điểm Cloud View chỉ mô tả vị trí nhìn vật lý khi điều kiện phù hợp. Nó không nói xác suất có mây và không bảo đảm săn mây thành công. Để kết hợp góc nhìn vật lý với điều kiện khí tượng theo giờ, bạn có thể tra cứu thêm bảng chỉ số thời tiết.
                </p>

                <div className="bg-[#f8fafc] border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-sm font-extrabold text-[#073161] mb-1">
                      Dự báo khí tượng hôm nay: Đỉnh Gió (92% khả năng gom mây) · Sống Lưng Khủng Long (88%)
                    </div>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Độ ẩm 91%, gió nhẹ 7km/h, nhiệt độ đêm 13°C. Khung giờ bình minh: 05:20 – 07:45.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentTab('weather')}
                    className="px-5 py-2.5 rounded-full bg-[#073161] hover:bg-[#0a3f7c] text-white text-xs font-bold whitespace-nowrap cursor-pointer transition-colors"
                  >
                    Xem dữ liệu thời tiết & săn mây →
                  </button>
                </div>
              </div>
            </section>

            {/* 9. Section: NGUYÊN TẮC THƯƠNG HIỆU (matching ref-footer.png) */}
            <section className="py-20 sm:py-24 px-4 sm:px-6 lg:px-8 bg-[#f8fafc] border-t border-slate-200/70 text-center">
              <div className="max-w-3xl mx-auto">
                <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-3">
                  NGUYÊN TẮC THƯƠNG HIỆU
                </p>
                <h2 className="text-3xl sm:text-5xl font-extrabold text-[#073161] tracking-tight leading-tight mb-5">
                  Không bán cái đẹp. Bán cái phù hợp.
                </h2>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl mx-auto">
                  Lựa chọn tốt không phải lúc nào cũng nổi bật nhất trên ảnh. Đó là lựa chọn phù hợp với cách bạn muốn đi và những điều bạn sẵn sàng đánh đổi.
                </p>
              </div>
            </section>

            {/* 10. Pre-Footer Navy-to-Teal CTA Banner (matching ref-footer.png) */}
            <section className="bg-gradient-to-r from-[#04244d] via-[#06366d] to-[#0a6b6e] py-16 sm:py-20 px-4 sm:px-6 lg:px-8 text-white">
              <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.14em] text-slate-200 mb-2">
                    TÀ XÙA, TRƯỚC KHI BẠN ĐẾN.
                  </p>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-3">
                    Phần phức tạp để chúng tôi lo.
                  </h2>
                  <p className="text-sm sm:text-base text-slate-200 max-w-xl leading-relaxed">
                    Bắt đầu bằng nơi lưu trú phù hợp. Các phần còn lại của chuyến sẽ chỉ được mở khi có dữ liệu và quy trình thật.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setCurrentTab('stay')}
                  className="bg-white hover:bg-slate-100 text-[#073161] font-extrabold text-sm px-7 py-4 rounded-full shadow-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  Bắt đầu tìm chuyến →
                </button>
              </div>
            </section>
          </>
        )}

        {/* Dedicated /stay View matching ref-stay.png */}
        {currentTab === 'stay' && (
          <div className="bg-[#f8fafc] pb-20">
            {/* Navy-to-Teal Banner */}
            <div className="bg-gradient-to-br from-[#04244d] via-[#06366d] to-[#0a6b6e] text-white py-14 sm:py-16 px-4 sm:px-6 lg:px-8">
              <div className="max-w-6xl mx-auto">
                <span className="inline-block px-3.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-white/15 border border-white/20 text-white mb-4">
                  LƯU TRÚ TÀ XÙA
                </span>
                <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight max-w-3xl mb-4">
                  Homestay Tà Xùa: xem phòng thật, view thật, giá rõ ràng
                </h1>
                <p className="text-sm sm:text-base text-slate-200 max-w-2xl leading-relaxed mb-8">
                  Chọn theo đúng loại phòng, sức chứa và bằng chứng đã công khai. Khi có đủ ngày, hệ thống đối chiếu từng đêm; dữ liệu thiếu không bao giờ được xem là còn phòng.
                </p>

                {/* Frosted Notice Box */}
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-5 max-w-2xl">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-200 mb-1">
                    THÔNG TIN CẦN LƯU Ý
                  </div>
                  <div className="text-sm sm:text-base font-extrabold text-white mb-1">
                    Giá và tình trạng phòng là hai dữ liệu độc lập.
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200">
                    Website chỉ hiển thị giá hoặc khả năng đáp ứng khi có dữ liệu tương ứng. Không suy luận từ dữ liệu thiếu.
                  </p>
                </div>
              </div>
            </div>

            {/* 2-Column Filter & Results Layout matching ref-stay.png */}
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Sidebar: Bộ lọc */}
                <aside
                  id="stay-filter-sidebar"
                  className="lg:col-span-4 bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-6"
                >
                  <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2 font-extrabold text-[#073161] text-base">
                      <SlidersHorizontal className="w-4 h-4 text-teal-700" />
                      <span>Bộ lọc</span>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-50 text-teal-800">
                      {stayFilterByAvailableDates || onlyCloudView || selectedArea !== 'all'
                        ? `Đang lọc (${stayFilteredListings.length} homestay)`
                        : 'Chưa lọc'}
                    </span>
                  </div>

                  {/* Lọc theo ngày trống (Date Range Availability Filter) */}
                  <div
                    id="stay-date-availability-filter"
                    className="space-y-3 bg-[#f8fafc] border border-teal-200/90 rounded-2xl p-4"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 whitespace-nowrap">
                        <Calendar className="w-4 h-4 text-teal-700 shrink-0" />
                        <h3 className="text-xs sm:text-sm font-extrabold text-[#073161]">
                          Lọc theo ngày trống
                        </h3>
                      </div>

                      <label className="inline-flex items-center gap-1.5 text-[11px] font-bold text-teal-800 cursor-pointer whitespace-nowrap bg-teal-100/70 px-2.5 py-1 rounded-full">
                        <input
                          id="toggle-filter-by-date"
                          type="checkbox"
                          checked={stayFilterByAvailableDates}
                          onChange={(e) => setStayFilterByAvailableDates(e.target.checked)}
                          className="rounded border-slate-300 text-[#073161] cursor-pointer"
                        />
                        <span>Còn phòng</span>
                      </label>
                    </div>

                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      Chọn khoảng thời gian cụ thể để hệ thống đối chiếu lịch phòng và chỉ hiển thị các homestay còn phòng trống.
                    </p>

                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label
                          htmlFor="stay-checkin-input"
                          className="block text-xs font-bold text-slate-700 mb-1"
                        >
                          Ngày nhận phòng
                        </label>
                        <input
                          id="stay-checkin-input"
                          type="date"
                          value={stayCheckIn}
                          onChange={(e) => {
                            const nextIn = e.target.value;
                            setStayCheckIn(nextIn);
                            setStayFilterByAvailableDates(true);
                            if (stayCheckOut && nextIn >= stayCheckOut) {
                              setStayCheckOut(nextIn);
                            }
                          }}
                          className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#073161]"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="stay-checkout-input"
                          className="block text-xs font-bold text-slate-700 mb-1"
                        >
                          Ngày trả phòng
                        </label>
                        <input
                          id="stay-checkout-input"
                          type="date"
                          value={stayCheckOut}
                          min={stayCheckIn}
                          onChange={(e) => {
                            setStayCheckOut(e.target.value);
                            setStayFilterByAvailableDates(true);
                          }}
                          className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#073161]"
                        />
                      </div>
                    </div>

                    {/* Quick Date Presets */}
                    <div>
                      <span className="block text-[11px] font-bold text-slate-500 mb-1.5">
                        Chọn nhanh lịch cuối tuần:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: '06/11 → 08/11', inDate: '2026-11-06', outDate: '2026-11-08' },
                          { label: '14/11 → 16/11', inDate: '2026-11-14', outDate: '2026-11-16' },
                          { label: '20/11 → 22/11', inDate: '2026-11-20', outDate: '2026-11-22' }
                        ].map((preset) => {
                          const isSelectedPreset =
                            stayFilterByAvailableDates &&
                            stayCheckIn === preset.inDate &&
                            stayCheckOut === preset.outDate;
                          return (
                            <button
                              key={preset.label}
                              type="button"
                              onClick={() => {
                                setStayCheckIn(preset.inDate);
                                setStayCheckOut(preset.outDate);
                                setStayFilterByAvailableDates(true);
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer border ${
                                isSelectedPreset
                                  ? 'bg-[#073161] text-white border-[#073161]'
                                  : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                              }`}
                            >
                              {preset.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-slate-200/80">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Người lớn
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={stayAdults}
                          onChange={(e) => setStayAdults(Math.max(1, Number(e.target.value)))}
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Trẻ em
                        </label>
                        <input
                          type="number"
                          min={0}
                          value={stayChildren}
                          onChange={(e) => setStayChildren(Math.max(0, Number(e.target.value)))}
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800"
                        />
                      </div>
                    </div>
                  </div>

                  {/* View & Verification */}
                  <div className="space-y-3 pt-4 border-t border-slate-100">
                    <h3 className="text-sm font-extrabold text-[#073161]">View & Thẩm định</h3>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Khu vực tại Tà Xùa
                      </label>
                      <select
                        value={selectedArea}
                        onChange={(e) => setSelectedArea(e.target.value)}
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 bg-white"
                      >
                        <option value="all">Tất cả khu vực</option>
                        <option value="Đỉnh Gió">Đỉnh Gió</option>
                        <option value="Sống Lưng Khủng Long">Sống Lưng Khủng Long</option>
                        <option value="Khe Cải">Bản Khe Cải</option>
                        <option value="Trung Tâm Tà Xùa">Trung Tâm Xã</option>
                        <option value="Mống Vàng">Mống Vàng</option>
                        <option value="Thảo Nguyên">Thảo Nguyên</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Hướng nhìn
                      </label>
                      <select
                        value={stayViewDirection}
                        onChange={(e) => setStayViewDirection(e.target.value)}
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 bg-white"
                      >
                        <option value="all">Tất cả</option>
                        <option value="mountain">Núi & Biển mây</option>
                        <option value="valley">Thung lũng</option>
                        <option value="garden">Vườn & Bản làng</option>
                      </select>
                    </div>

                    <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={onlyAvailable}
                        onChange={(e) => setOnlyAvailable(e.target.checked)}
                        className="rounded border-slate-300 text-[#073161]"
                      />
                      <span>Có thẩm định & lịch trống đang hiệu lực</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={onlyCloudView}
                        onChange={(e) => setOnlyCloudView(e.target.checked)}
                        className="rounded border-slate-300 text-[#073161]"
                      />
                      <span>Có Cloud View từ giường đã thẩm định</span>
                    </label>
                  </div>

                  {/* Road Access */}
                  <div className="space-y-3 pt-4 border-t border-slate-100">
                    <h3 className="text-sm font-extrabold text-[#073161]">Tiếp cận</h3>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Ô tô tiếp cận
                      </label>
                      <select
                        value={stayCarAccess}
                        onChange={(e) => setStayCarAccess(e.target.value)}
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 bg-white"
                      >
                        <option value="all">Không yêu cầu</option>
                        <option value="yes">Ô tô vào tận nơi</option>
                        <option value="motorbike">Ưu tiên xe máy</option>
                      </select>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        showToast(
                          `Đã lọc ${stayFilteredListings.length} homestay còn phòng trống (${stayCheckIn} → ${stayCheckOut})!`
                        )
                      }
                      className="w-full bg-[#073161] hover:bg-[#0a3f7c] text-white font-extrabold text-xs py-3 rounded-full uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      ÁP DỤNG BỘ LỌC ({stayFilteredListings.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedArea('all');
                        setOnlyCloudView(false);
                        setOnlyAvailable(false);
                        setStayViewDirection('all');
                        setStayCarAccess('all');
                        setStayFilterByAvailableDates(false);
                      }}
                      className="w-full text-xs font-bold text-slate-500 hover:text-[#073161] py-1.5 cursor-pointer"
                    >
                      Xóa tất cả bộ lọc
                    </button>
                  </div>
                </aside>

                {/* Right Column: Summary Strip + Filtered Listings */}
                <div className="lg:col-span-8 space-y-6">
                  {/* Top Summary Bar matching ref-stay.png */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-5 grid grid-cols-1 sm:grid-cols-3 gap-4 shadow-2xs">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-[#073161]">
                          Lọc theo ngày trống
                        </div>
                        <div className="text-xs text-slate-600 font-semibold">
                          {stayFilterByAvailableDates
                            ? `${stayCheckIn} → ${stayCheckOut}`
                            : 'Tất cả các ngày'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                        <Users className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-[#073161]">Khách</div>
                        <div className="text-xs text-slate-500">
                          {stayAdults} người lớn · {stayChildren} trẻ em
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-[#073161]">
                          Kết quả kiểm tra phòng
                        </div>
                        <div className="text-xs text-emerald-700 font-bold">
                          {stayFilteredListings.length} homestay còn phòng trống
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Verified Homestays List Filtered by Date Range */}
                  {stayFilteredListings.length === 0 ? (
                    <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-3">
                      <h3 className="text-lg font-extrabold text-[#073161]">
                        Không có homestay còn phòng trống trong khoảng {stayCheckIn} → {stayCheckOut}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto">
                        Vui lòng chọn khoảng ngày khác hoặc tắt bộ lọc ngày trống để xem toàn bộ danh sách homestay đã thẩm định.
                      </p>
                      <button
                        type="button"
                        onClick={() => setStayFilterByAvailableDates(false)}
                        className="px-5 py-2.5 rounded-full bg-[#073161] text-white text-xs font-bold cursor-pointer"
                      >
                        Xem tất cả homestay không giới hạn ngày
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {stayFilteredListings.map((listing) => {
                        const dateCheck = isHomestayAvailableInDateRange(
                          listing,
                          stayCheckIn,
                          stayCheckOut,
                          bookings
                        );
                        const shortIn = stayCheckIn.slice(5).split('-').reverse().join('/');
                        const shortOut = stayCheckOut.slice(5).split('-').reverse().join('/');
                        return (
                          <div key={listing.id} className="flex flex-col">
                            {stayFilterByAvailableDates && (
                              <div className="mb-2 px-3.5 py-2 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between gap-2">
                                <span className="flex items-center gap-1.5 truncate">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  <span className="truncate">
                                    Còn {dateCheck.availableRoomsCount} phòng trống ({shortIn} – {shortOut})
                                  </span>
                                </span>
                                <span className="text-[11px] font-extrabold text-emerald-700 whitespace-nowrap shrink-0">
                                  Sẵn sàng đặt
                                </span>
                              </div>
                            )}
                            <ListingCard
                              listing={listing}
                              onSelect={(l) => setSelectedListingDetail(l)}
                              isSaved={userProfile.savedListings.includes(listing.id)}
                              onToggleSave={handleToggleSave}
                            />
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Khám phá theo nhu cầu rõ ràng (matching ref-stay.png bottom) */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 mt-8">
                    <h2 className="text-xl font-extrabold text-[#073161] mb-4">
                      Khám phá theo nhu cầu rõ ràng
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        {
                          label: 'Homestay Tà Xùa theo nhu cầu phòng →',
                          action: () => {
                            setSelectedCategory('homestay');
                            setOnlyCloudView(false);
                          }
                        },
                        {
                          label: 'Phòng có hướng nhìn ra núi hoặc thung lũng →',
                          action: () => {
                            setSelectedCategory('homestay');
                            setOnlyCloudView(true);
                          }
                        },
                        {
                          label: 'Phòng tại khu vực Đỉnh Gió trung tâm →',
                          action: () => setSelectedArea('Đỉnh Gió')
                        },
                        {
                          label: 'Nơi lưu trú khu vực Bản Khe Cải yên tĩnh →',
                          action: () => setSelectedArea('Khe Cải')
                        }
                      ].map((item, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={item.action}
                          className="text-left p-3.5 rounded-2xl border border-slate-200 hover:border-[#073161] text-xs font-bold text-[#073161] transition-colors cursor-pointer"
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dedicated /verified View */}
        {currentTab === 'verified' && (
          <div className="bg-[#f8fafc] py-14 px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto space-y-8">
              <div className="bg-gradient-to-br from-[#04244d] via-[#06366d] to-[#0a6b6e] rounded-3xl p-8 sm:p-12 text-white">
                <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-200 mb-2">
                  PHƯƠNG PHÁP THẨM ĐỊNH TÀ XÙA TRIP
                </p>
                <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-4">
                  Đi thật. Biết trước.
                </h1>
                <p className="text-sm sm:text-base text-slate-200 max-w-2xl leading-relaxed">
                  Chúng tôi tách biệt từng lớp thông tin: danh tính phòng, góc nhìn vật lý (Cloud View), độ khó của đường đèo vào homestay và ngày xác minh gần nhất để bạn không bao giờ phải đặt phòng qua ảnh quảng cáo mơ hồ.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-slate-200 rounded-3xl p-6">
                  <h3 className="text-lg font-extrabold text-[#073161] mb-2">
                    1. Tách biệt Loại phòng & Phòng cụ thể (Room ID)
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Trong cùng một homestay tại Tà Xùa, căn Bungalow số 01 có thể nhìn thẳng ra biển mây Đỉnh Gió nhưng căn số 04 lại bị mái nhà trước che khuất. Hồ sơ của chúng tôi gắn nhãn theo từng Room ID.
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-3xl p-6">
                  <h3 className="text-lg font-extrabold text-[#073161] mb-2">
                    2. Đường vào & Khả năng tiếp cận
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Ghi rõ độ dốc đường nhánh vào từng cơ sở (ô tô 16 chỗ vào tận sân, hay phải gửi xe ở trục chính và đi bộ/xe máy 200m).
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentTab === 'map' && (
          <InteractiveMapSection
            listings={listings}
            landmarks={CLOUD_LANDMARKS}
            onSelectListing={(l) => setSelectedListingDetail(l)}
          />
        )}

        {currentTab === 'weather' && <CloudForecastWidget forecasts={CLOUD_FORECASTS} />}

        {currentTab === 'bus' && (
          <div className="bg-[#f8fafc] py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-teal-700 mb-2">
                    TUYẾN XE & ĐIỂM ĐÓN DỌC ĐƯỜNG
                  </p>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-[#073161]">
                    Xe Limousine & Cabin Đi Tà Xùa
                  </h2>
                  <p className="text-sm text-slate-600 mt-1">
                    Hà Nội ➔ Đại Lộ Thăng Long ➔ Sơn Tây ➔ Thanh Sơn ➔ Phù Yên ➔ Bắc Yên ➔ Tà Xùa. Tự động tính giờ đón ước tính.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsBusModalOpen(true)}
                  className="bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold px-6 py-3 rounded-full text-xs transition-all shadow-md self-start sm:self-auto cursor-pointer"
                >
                  Mở Sơ Đồ Ghế & Đặt Vé Ngay
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {trips.map((trip) => (
                  <div
                    key={trip.id}
                    className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-3">
                        <span className="font-extrabold text-[#073161] text-xl tabular-nums">
                          {trip.departureTime}
                        </span>
                        <span className="bg-teal-50 text-teal-800 px-3 py-1 rounded-full font-bold">
                          {trip.busType}
                        </span>
                      </div>

                      <h3 className="font-extrabold text-[#073161] text-base mb-1">
                        {trip.operatorName}
                      </h3>
                      <p className="text-xs text-slate-500 mb-4">{trip.route}</p>

                      <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200/80 text-xs space-y-1.5 mb-5">
                        <div className="text-[#073161] font-bold">Điểm đón dọc tuyến:</div>
                        <ul className="text-slate-600 space-y-1 text-[11px]">
                          {trip.stops.slice(0, 4).map((s, idx) => (
                            <li key={idx}>
                              · {s.name} (+{s.minuteOffset} phút)
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] text-slate-500 block">Giá vé niêm yết:</span>
                        <span className="text-base font-extrabold text-[#073161] tabular-nums">
                          {trip.baseFare.toLocaleString()}đ/ghế
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setIsBusModalOpen(true)}
                        className="bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold text-xs px-4 py-2.5 rounded-full transition-colors cursor-pointer"
                      >
                        Chọn Ghế & Điểm Đón
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {currentTab === 'itinerary' && <AIItineraryGenerator />}

        {currentTab === 'community' && (
          <CommunitySection posts={communityPosts} onAddPost={handleAddCommunityPost} />
        )}

        {currentTab === 'partner' && (
          <PartnerDashboard
            partnerListing={partnerListing}
            bookings={bookings}
            wallet={partnerWallet}
            onUpdateAvailability={handleUpdateAvailability}
            onConfirmBooking={handleConfirmBooking}
            onCheckInBooking={handleCheckInBooking}
            onCompleteBooking={handleCompleteBooking}
            billingEnabled={billingEnabled}
          />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard
            listings={listings}
            billingEnabled={billingEnabled}
            onToggleBilling={handleToggleBilling}
            onUpdateTier={handleUpdateTier}
            onApproveListing={handleApproveListing}
            onRejectListing={handleRejectListing}
            verifiedMembersCount={1240}
          />
        )}
      </main>

      {/* Floating AI Assistant Widget in Bottom-Right Corner matching ref-hero.png */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3">
        {showAiGreeting && currentTab !== 'itinerary' && (
          <aside
            aria-label="Gợi ý từ Trợ lý AI"
            className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xl w-80 sm:w-88 relative"
          >
            <button
              type="button"
              onClick={() => setShowAiGreeting(false)}
              aria-label="Ẩn lời chào Trợ lý AI"
              className="absolute top-3.5 right-3.5 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 text-xs font-extrabold text-[#073161] mb-2">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Trợ lý AI Tà Xùa Trip</span>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
              Bạn muốn mình gợi ý phòng phù hợp và nói rõ điều gì còn chưa xác nhận không?
            </p>

            <button
              type="button"
              onClick={() => {
                setShowAiGreeting(false);
                setCurrentTab('itinerary');
              }}
              className="bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold text-xs px-4 py-2.5 rounded-full transition-colors cursor-pointer"
            >
              Hỏi thử một câu
            </button>
          </aside>
        )}

        <button
          type="button"
          onClick={() => setCurrentTab('itinerary')}
          aria-label="Mở Trợ lý AI Tà Xùa Trip"
          className="bg-[#073161] hover:bg-[#0a3f7c] text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-full shadow-xl flex items-center gap-2 border border-white/15 transition-transform active:scale-95 cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>✨ Trợ lý AI</span>
        </button>
      </div>

      {/* Global Modals */}
      {selectedListingDetail && (
        <ListingDetailModal
          listing={selectedListingDetail}
          reviews={reviews.filter((r) => r.listingId === selectedListingDetail.id)}
          userBookings={bookings.filter((b) => b.listingId === selectedListingDetail.id)}
          onClose={() => setSelectedListingDetail(null)}
          onBookSuccess={handleBookingSuccess}
          onAddReview={handleAddReview}
          onCompleteBooking={handleCompleteBooking}
        />
      )}

      {isBusModalOpen && (
        <BusBookingModal
          trips={trips}
          onClose={() => setIsBusModalOpen(false)}
          onBookSuccess={handleBookingSuccess}
        />
      )}

      {isSosModalOpen && <SosModal onClose={() => setIsSosModalOpen(false)} />}

      {isPointsModalOpen && (
        <PointsModal
          profile={userProfile}
          onClose={() => setIsPointsModalOpen(false)}
          onRedeemReward={handleRedeemReward}
        />
      )}

      {activeSuccessBooking && (
        <BookingSuccessModal
          booking={activeSuccessBooking}
          onClose={() => setActiveSuccessBooking(null)}
        />
      )}

      {/* Footer matching https://taxuaslay1.vercel.app/ */}
      <footer className="bg-white border-t border-slate-200/90 text-slate-600 py-14 px-4 sm:px-6 lg:px-8 text-xs">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-full bg-[#073161] text-white flex items-center justify-center">
                <Mountain className="w-4 h-4" />
              </div>
              <div>
                <div className="font-extrabold text-sm tracking-[0.1em] text-[#073161] uppercase">
                  TÀ XÙA TRIP
                </div>
                <div className="text-[11px] text-slate-500">Đi thật. Biết trước.</div>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Nền tảng du lịch địa phương giúp bạn biết rõ nơi ở, bằng chứng và điều cần lưu ý trước khi lên đường.
            </p>
            <p className="text-[11px] font-extrabold tracking-widest text-teal-700">
              THẬT · HIỂU · TRỌN VẸN
            </p>
          </div>

          <div>
            <h2 className="font-extrabold text-[#073161] uppercase tracking-wider mb-3 text-xs">
              DỊCH VỤ
            </h2>
            <ul className="space-y-2 text-slate-600">
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('stay')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Tìm chuyến đi
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('stay')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Lưu trú
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('map')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Bản đồ tọa độ săn mây
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('bus')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Xe khách · Đón dọc tuyến
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('motorbike');
                    setCurrentTab('explore');
                  }}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Xe máy · cần xác nhận
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('weather')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Săn mây / Cloud View
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="font-extrabold text-[#073161] uppercase tracking-wider mb-3 text-xs">
              HỖ TRỢ
            </h2>
            <ul className="space-y-2 text-slate-600">
              <li>
                <button
                  type="button"
                  onClick={() => setIsSosModalOpen(true)}
                  className="text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
                >
                  Cứu hộ Đèo Chẹn & Núi 24/7
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('itinerary')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Trợ lý AI Lịch trình Offline
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('community')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Cộng đồng ghép xe & review
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="font-extrabold text-[#073161] uppercase tracking-wider mb-3 text-xs">
              VỀ CHÚNG TÔI
            </h2>
            <ul className="space-y-2 text-slate-600 mb-4">
              <li>
                <button
                  type="button"
                  onClick={() => setCurrentTab('verified')}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Phương pháp thẩm định
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    setUserRole('partner');
                    setCurrentTab('partner');
                  }}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Cổng Đối tác / Chủ cơ sở
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    setUserRole('admin');
                    setCurrentTab('admin');
                  }}
                  className="hover:text-[#073161] cursor-pointer"
                >
                  Quản trị thẩm định (Admin)
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-6xl mx-auto mt-10 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 Tà Xùa Trip.</p>
          <p className="font-semibold text-[#073161]">Đi thật. Biết trước.</p>
        </div>
      </footer>
    </div>
  );
}
